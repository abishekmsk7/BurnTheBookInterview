-- MySQL dump 10.13  Distrib 8.0.36, for Linux (aarch64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_lwxfhvnzhgyckxpmjmjvcpbydegmnyvcuorq` (`primaryOwnerId`),
  CONSTRAINT `fk_lwxfhvnzhgyckxpmjmjvcpbydegmnyvcuorq` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nyinavhvjlxfuzfqiihoyoysdgzwfghbocyo` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_etptsoyyqhlftjytcmjpcbovtzukriiryebv` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_lytfdjdblvdxlxeuxbthtjkxfgujgjqrtdol` (`dateRead`),
  KEY `fk_poahktwdxkejackvkzkilpkulkayghftxsjx` (`pluginId`),
  CONSTRAINT `fk_poahktwdxkejackvkzkilpkulkayghftxsjx` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sncqaycsmyuusgtypogknpkjsgjvbzmuzaex` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ktfdrsgyxoicdrdkyxphtfwbgdmdlkjhcazr` (`sessionId`,`volumeId`),
  KEY `idx_bnsdtodsxolpjgsnfxcuxxnfhgbegkeiahkr` (`volumeId`),
  CONSTRAINT `fk_dnvtjiyfkotccohkxjrgtnwketcwmfjiehte` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_usursqvsndsuobotyqalquvsbxwpjhbtmnsl` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_adcenjhvkasqvfqhzosnnajyqturygbwvfqm` (`filename`,`folderId`),
  KEY `idx_xnemrokpminphhgvaxjzcljazihgufrebpwn` (`folderId`),
  KEY `idx_fauytvxmahxwdmzbfhsftrikrwuurdehfisj` (`volumeId`),
  KEY `fk_nknfhirrodwjmyjhwcpuijjvhadgrqfvbgik` (`uploaderId`),
  CONSTRAINT `fk_frpigmzvrrshdmjhrgxbdgjnxpwmxnmvmrxh` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nknfhirrodwjmyjhwcpuijjvhadgrqfvbgik` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_odrdynnobofoxxbjgukoqnkqvgvdtmlicqjz` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xlleliefhtilfilczfdfamtrvgmsnxjzyvfg` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_dgotmdukywohyldxatlkxtelpwbouagtmqjp` (`siteId`),
  CONSTRAINT `fk_cqwyywzejyohlkoruziwmlsosjcupdrwolpj` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dgotmdukywohyldxatlkxtelpwbouagtmqjp` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `oldTimestamp` int unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sobgnkuaqudkaztuaecrldnnjwzcqxselifb` (`userId`),
  CONSTRAINT `fk_sobgnkuaqudkaztuaecrldnnjwzcqxselifb` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_crbjeybuqnhcbmtpsycdlxyhfgeyenhqvyuq` (`groupId`),
  KEY `fk_trfymsnkoujmninwveynrgwjbnnnlumohnqp` (`parentId`),
  CONSTRAINT `fk_gsntlihxecaxurtqixupzjpeqzhipoizcqbp` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_trfymsnkoujmninwveynrgwjbnnnlumohnqp` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ubvogfynttwtdyxtnjjvnsyhrpyiqpbxpvyq` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pkgtpbjdwwaxjreignkuynubcenbysfjmmur` (`name`),
  KEY `idx_iscteejzcpqaktbnrvmwmkcybedparzxnulv` (`handle`),
  KEY `idx_flkxfwruhbtezyfmadhdeuyyizyexhrgourw` (`structureId`),
  KEY `idx_fqeruedvidxccbhalxngpkccwgfwwxgbgqip` (`fieldLayoutId`),
  KEY `idx_szjrukipzfaejggrnomgjsfihuswdubzhybd` (`dateDeleted`),
  CONSTRAINT `fk_redxijjjhsrajtazygsvsxwtijagxmpffpge` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rtxzrdtaohgjxsgnxgacfyvyyeqcfwxqidvj` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_aanrszhiunwuiihdnsgrfaytzeejhxhbtffm` (`groupId`,`siteId`),
  KEY `idx_jdssnyijfluieetwfhaicpxwzrkhezwsgwlq` (`siteId`),
  CONSTRAINT `fk_lmijrgwvlpkpbsubkpnppdrjdmolflptmvoi` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wmvswepshmtexcmosplclmcwvxcuutimeacr` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_vgejaixhdnvjbqppjthivcfwidjxnauojpya` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_wccyyoytllisjphqlhqxfrkynllswwncdvjd` (`siteId`),
  KEY `fk_elcgjsantcvchtswkliyjgdjsjxslvwwsozc` (`userId`),
  CONSTRAINT `fk_elcgjsantcvchtswkliyjgdjsjxslvwwsozc` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_olcsjppailwkyhcsqljkaoppdjisrtorpzid` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wccyyoytllisjphqlhqxfrkynllswwncdvjd` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_qsjhcytaxhkejpbtkjeywpyxfpnvgseydvvh` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_rshmajgxocihjqsophwbhjveyfewxslmwgov` (`siteId`),
  KEY `fk_ucqetmiajacxdgaaaipvauvmjrruntcgrjvl` (`fieldId`),
  KEY `fk_hgyelbnvagcihndyuofafikjabubtxvgopzh` (`userId`),
  CONSTRAINT `fk_hgyelbnvagcihndyuofafikjabubtxvgopzh` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_rshmajgxocihjqsophwbhjveyfewxslmwgov` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ucqetmiajacxdgaaaipvauvmjrruntcgrjvl` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ydesccjkvzfyhscssenmxmwycsupicmhzsyj` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_yipdsvlxlgouyvwqfqneejnwxjhpmutdhlja` (`userId`),
  CONSTRAINT `fk_yipdsvlxlgouyvwqfqneejnwxjhpmutdhlja` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bmduuxppgbzuwrsulzquuwvlreeowfhifntc` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_yztdsvdcdrizxfmmcbnochizmxmhltsbpqsa` (`creatorId`,`provisional`),
  KEY `idx_gftxnqrhktrgpxgpzdpksuymwptyhhminjvp` (`saved`),
  KEY `fk_bzkhgfokuotdhyxviuodtpajwvpbcmqwolmk` (`canonicalId`),
  CONSTRAINT `fk_bzkhgfokuotdhyxviuodtpajwvpbcmqwolmk` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_etmygajifgurwbdixteibtophvfiapfzddet` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_zkqcbnkiciwolbnqpiqrdiawzuftsvfribhx` (`elementId`,`timestamp`,`userId`),
  KEY `fk_sexgxhtkfiicqgobbhigtrvndtqwcrfidhfw` (`userId`),
  KEY `fk_jxbgyrukbjabvnicrhorgkeylukbuuudofha` (`siteId`),
  KEY `fk_lfylroepmoduptkjfiptineiceaxytlnwydd` (`draftId`),
  CONSTRAINT `fk_jxbgyrukbjabvnicrhorgkeylukbuuudofha` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lfylroepmoduptkjfiptineiceaxytlnwydd` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nqbdgmulgtucgcamkojpgmuiafmxanoxvngi` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sexgxhtkfiicqgobbhigtrvndtqwcrfidhfw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zfqtrnlfsbttlakshdaxtfpuxfwqpzjarxwv` (`dateDeleted`),
  KEY `idx_dmwjqlkicyvqtcklvwgergdvupsxnveixbtu` (`fieldLayoutId`),
  KEY `idx_mpwjddrwoxqprzbqyxduwicglgmexzroaeje` (`type`),
  KEY `idx_rtdyplnktiiwsbdgiwcqqjrtxtwkllaegtwd` (`enabled`),
  KEY `idx_litewfwwvvvpnfuyifpeteultbaiyrdpkauc` (`canonicalId`),
  KEY `idx_ncvgfllxhirtjnefvzyhrrszyabahgtduiab` (`archived`,`dateCreated`),
  KEY `idx_qemhnqqsjpwmcqnvaocmmyplpgseoywbxvzk` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_kulberxlcwrnxygpykhezrqifgiqckneelco` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_jgeqqggyritoggqngpfpgqwocfsxsuaixqpd` (`draftId`),
  KEY `fk_kaxhwvldledcocfnwvrlojoijjkeadijzxbk` (`revisionId`),
  CONSTRAINT `fk_jgeqqggyritoggqngpfpgqwocfsxsuaixqpd` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kaxhwvldledcocfnwvrlojoijjkeadijzxbk` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qrnopsqqrcwxchqkelpnhzqmmrcyhgazblsu` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rfubsfevpfxfjkxuvszzbkeomeezmhbpbsth` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_minsvjiwwphgpghhywmaougxqeueclxyedta` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_yutpapptejhkshdqgnrmlksblhdfyczgphjc` (`ownerId`),
  CONSTRAINT `fk_ghxulqnygehfeyzzdtevfvgtrsjwvfrqwdwa` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yutpapptejhkshdqgnrmlksblhdfyczgphjc` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ugtrwwavquypoazbrwenxfdqkladhcizgxip` (`elementId`,`siteId`),
  KEY `idx_xsbzgmwjjpykbcooimbcanmdczwczabafgvi` (`siteId`),
  KEY `idx_pgdtdnbyuwttxhawgfrlkbodzsadwjrdclyn` (`title`,`siteId`),
  KEY `idx_fhmqvaxwbfqahggmdeorhamzttuszlzsxfyp` (`slug`,`siteId`),
  KEY `idx_oatilonkjynfgatbboqoisodgzhskjyvmwwn` (`enabled`),
  KEY `idx_ertmntyjqnmanjprrlqhvlonhluouaagstpa` (`uri`,`siteId`),
  CONSTRAINT `fk_ghbxzqvetkatmiohgwwrirddwmuypkklwavz` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_yilhkvizlohgdasxazuprpajsjofzxlzotiy` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `deletedWithSection` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_nqmoyflwpihvdcfjasrakqyczipfxdtzlgzt` (`postDate`),
  KEY `idx_srgnycpkpojbvqefnfzfhsovpirhaaumfdgs` (`expiryDate`),
  KEY `idx_waqnopbcjtxjbolvpysuohcvknysdvutntfn` (`sectionId`),
  KEY `idx_cjltwfpilacmwvkdawnrkzcgnthngpbhgega` (`typeId`),
  KEY `idx_eilumditrepywjjzvfnwlpxamkxjalmsyxqw` (`primaryOwnerId`),
  KEY `idx_phxitafbxtoykktqruknwrubtjkyyqvarned` (`fieldId`),
  KEY `fk_rqeqjacpxslzwdctjrhvkcemtgnyxdwkzton` (`parentId`),
  CONSTRAINT `fk_amgjncepeynxtqcngfiuoimzbsmrrfnvckgu` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eynecfnnqvogxobxcddmyuasvieedafukoet` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qiigrywuesattcqlbnymwaaroekxopqknxdk` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rqeqjacpxslzwdctjrhvkcemtgnyxdwkzton` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_sfwlzjuqupqirviotjrcdlghyjsffkaekexd` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wdsktxtcfgrguwoofilsbnlbsarsnhwptqdo` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_uouaktoolwlrwvxzlwbcoggyycqensqjrbsg` (`authorId`),
  KEY `idx_kehsmhlsfmefiwmrcpphklvryzgcrmrlbxbt` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_aesyagkpspawhnrnxkzptkpbapypvrhbbriv` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vkehifhnlzdxgsmpykkqenzliqpllyapcxdq` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tpohibekujngqotciqneuwfydnsjzboumfew` (`fieldLayoutId`),
  KEY `idx_kmhuzljhknvbqqolyifmtwzbjmjbyeuygxst` (`dateDeleted`),
  CONSTRAINT `fk_ufiaawegasssxzsxjioqpwtuzmhtkxbjwfox` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_agcotgktqbedwanrbrdeqoncmjmayapkkjbt` (`dateDeleted`),
  KEY `idx_ioianlergsirzhzxjylyabvrmtpydthmssvg` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_oklpeqwjbsloeocleawsfhjmldxvdbroejnz` (`handle`,`context`),
  KEY `idx_zplxetkaaiacwicrgmmxhelydrxrsbfaatom` (`context`),
  KEY `idx_vfiattycvkdbhgieyziyawxqryymsxxnjmqu` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_declwminwmwvgbiagswpfhahzlbnqmkcyhnk` (`name`),
  KEY `idx_iahpaqvhrksolpzqevlzhrvcbkkndgngqfvv` (`handle`),
  KEY `idx_hbpizcjceonmsqlxiqbbzwfbqsimdkkqhhof` (`fieldLayoutId`),
  KEY `idx_trwrhwptacgesjbkbuxzovjqmbamfcirnjmb` (`sortOrder`),
  CONSTRAINT `fk_falangjvtcznsnwszzndcketwgaoeggkcpxx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rwfyjkidgatlhheofjheqddncapuvlwfsunz` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lrknwuyegxajprcphwqperhsrzrzjvomnbgd` (`accessToken`),
  UNIQUE KEY `idx_rirltnkscjiboayrmbwouhfizqhelgvzkija` (`name`),
  KEY `fk_xctjvpvvvaxiznxxtwkwxakllviuhyiygxmx` (`schemaId`),
  CONSTRAINT `fk_xctjvpvvvaxiznxxtwkwxakllviuhyiygxmx` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_udfjvezpdlxftuzdkawivlvltekikjltuhbl` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yemnyxawdnucrzarqhocpcvbfyikkojjjjmk` (`name`),
  KEY `idx_duvmmyttshzerzvyvxkcqujnhkxqagmfsuvk` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tbueqtnujqqnuobrrzyyemnpowpnfwcyiqgf` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_oodmrbzjrlffqebjlujrsrktmepjljwgosum` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_zgnnkjgxxsgxtkarywlnflosmxvhxbgmifjr` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_vjnxrmvkkdcviposuuhpxuclcqatuemlkfda` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=301 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_buuwmixnwqbizobnbnyancbtdfcyvrwafvbw` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_ztryfcnjnminbxdwvsfmwaqtfshplbvvmbxy` (`sourceId`),
  KEY `idx_uqvceimccwoiuedprajjpdzcgphbixpyplyk` (`targetId`),
  KEY `idx_tnujixlpvtkcaoorghpwselxpmbfztfvzkpl` (`sourceSiteId`),
  CONSTRAINT `fk_joxrvytufjgyevvihjqazzmomzsdqyxpkuxd` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xuqblavvhtjcmjrlvvffrbfzourevtujojpr` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yewlqdzhoxsyesibpqlzfuigvbhgogslqfbz` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lvkvydealnizituyitteyqekspyjmcewperi` (`canonicalId`,`num`),
  KEY `fk_vbmklrsobuznkrperaatfpqeqcxgltoiqrip` (`creatorId`),
  CONSTRAINT `fk_vbmklrsobuznkrperaatfpqeqcxgltoiqrip` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zvxktirjlxoaztehhehemiayvzinunsjekzq` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_artvmovffuetepyrpsaqkbrzpfjlecisdcsi` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_klujnucuyiwkhhheoojkvflhxohvfsgxytsy` (`handle`),
  KEY `idx_pemcmupwqzpoqgdtmdqbqgmthelqtjoyecvj` (`name`),
  KEY `idx_bhrwpixzyvvikucmrwytiznjefvsrpipoxut` (`structureId`),
  KEY `idx_yjpnpbqswblucmqxzdqkcvoyzswcpnnvvaxl` (`dateDeleted`),
  CONSTRAINT `fk_fkyiqymhuevgiemejmsvunxcxsfeercwfwas` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_wfxwelygdfwoexzkhmgrwwjmblyzdpqkoprg` (`typeId`),
  CONSTRAINT `fk_qnhethwlszmcbstlzklhwghkmefxtdarwior` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wfxwelygdfwoexzkhmgrwwjmblyzdpqkoprg` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pevwzwuydqvcxbdzitunbukoynnotxkkkaai` (`sectionId`,`siteId`),
  KEY `idx_sukqjvobadctgremabobtsfwwfowcacrmrub` (`siteId`),
  CONSTRAINT `fk_fdtdfpwtvyoammhrxlnqwaieoktynamgbpam` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gljqwsoiuulumqrofyubmqmzkaytzmapwiwk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_krzzpjjjhqbokoghogjriwmkcbwcswlbbdtg` (`uid`),
  KEY `idx_fyurrekxzkqcuohitiewstkhcawjexmdlegd` (`token`),
  KEY `idx_omjvvsnbszpnrykimodjcztysundzrigtqer` (`dateUpdated`),
  KEY `idx_qjacvbhxatdttynzxrevhsubxromkepisguq` (`userId`),
  CONSTRAINT `fk_grsepwwaxmbqgqythuobkuehccnveagbcubj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cekignllnrvkiuhseobfuqbvmbrbaddyzwhk` (`userId`,`message`),
  CONSTRAINT `fk_vcknzhocxxkvkcxnrelkzinobniwrliufnew` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_goajyetoxigwwplreujuragtwfnaonnbcjpc` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_amxmudyvrahkzqapehurcqiutuouhaywlzce` (`dateDeleted`),
  KEY `idx_wtzrthyzjntwfltfjtsixnamxeeylkxeygrr` (`handle`),
  KEY `idx_gwcxgxbmqffwdtjorjknqelalaxhdpfmrojq` (`sortOrder`),
  KEY `fk_kmnxhhuppyvlgydbkhontamkipvdupnbaeiv` (`groupId`),
  CONSTRAINT `fk_kmnxhhuppyvlgydbkhontamkipvdupnbaeiv` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sso_identities`
--

DROP TABLE IF EXISTS `sso_identities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_identities` (
  `provider` varchar(255) NOT NULL,
  `identityId` varchar(255) NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`provider`,`identityId`,`userId`),
  KEY `fk_nksugtcszydbupvgtgtikdwenogppvwnwgsj` (`userId`),
  CONSTRAINT `fk_nksugtcszydbupvgtgtikdwenogppvwnwgsj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zaqjuariwsblmwoknbsocfxqbypdtibclciv` (`structureId`,`elementId`),
  KEY `idx_jvbsjtznfqksgeymnwvlezfnpewdjvqsjxty` (`root`),
  KEY `idx_gsdyrqdgkvepbjxrxgaogymyasfmabvtbykv` (`lft`),
  KEY `idx_kuanqimzoauwvzmejqqikcjtvnicfixxxgsp` (`rgt`),
  KEY `idx_tlglqifpjglmjnlrgvtnhmventjewutwglmt` (`level`),
  KEY `idx_ttnkpicojlqovogbuwudbcnjvbdpnfernnov` (`elementId`),
  CONSTRAINT `fk_suibjorjsiqnmbsbcxhflgdsdyudanharnwf` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sustjubanxdlaittmmzfbxlbwfvsnyvxwcdi` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hlkyhxtysmtrmxdwenwkebamjozcvnuvaybx` (`key`,`language`),
  KEY `idx_rodqbmpbezjklzhmkboycgvmlxageqwfbpso` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cdhpeirgnrywoohnppolunbzbimmppxachtb` (`name`),
  KEY `idx_exmrmzcfkoqzrswppetyraludhaadfvdfeez` (`handle`),
  KEY `idx_gcvgdbgnkaoycgvbtrpbvtyaovvosuqvhqlh` (`dateDeleted`),
  KEY `fk_pkrrdyldgcbxxlrxstvzejxyafcafhksbbsz` (`fieldLayoutId`),
  CONSTRAINT `fk_pkrrdyldgcbxxlrxstvzejxyafcafhksbbsz` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_nyxndsvmwxzjepugptdocilmxssjgspfossz` (`groupId`),
  CONSTRAINT `fk_fvbcupcndtwtjzwucvdenmrcufjbopwbnhmj` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zjjdsrbbuuvsscngmyikvrblmayzcujneeno` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hleprotmgttgxzegssdfdqpxcollgqamuqfn` (`token`),
  KEY `idx_cdjbtzxtzmelmsktjcthjuklqqxaypfhvftx` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ofajhqhzgwnmzekvxgeakvvxdyughqmbzvlc` (`handle`),
  KEY `idx_winachexhehdabjaqznaoorvqygzzbmwwodx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wjttvwrnrgqodwyjpyniqacckzjxxxvbsyvm` (`groupId`,`userId`),
  KEY `idx_wcwfkhzrlddufkfggncdqyveyngbogurutev` (`userId`),
  CONSTRAINT `fk_ehwsgifgazoqnekhxnfycmmiizzifpikuxqu` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nndjwnwxfaxnsmraimirocaewhjdngbqxcon` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kmomasziunltlbuutxiroeygwjtrlajlegpy` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_huduozsqalcgptekegjtkwgsetzgcifqsuto` (`permissionId`,`groupId`),
  KEY `idx_mqpyulchgwwzmgvokccvojvovjqgxlsogdzj` (`groupId`),
  CONSTRAINT `fk_fajfsibdmmhyaczjahixuzdmkfsrfdizpvjl` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mfwfgrkvrxvblyjwsxxneqtthecqygfpytuz` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_myilwkrwtjnucftfgrbsyywexeupdabzvmkh` (`permissionId`,`userId`),
  KEY `idx_jwfzioedvblgfdgexyztbenawycuhpzudxsw` (`userId`),
  CONSTRAINT `fk_hbqjztuzutcpymcdrzyngbpfehhnxiaseatc` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jhgywnncrzllwdoprrxaoalpyzfpbyvlzjgy` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_otrnlydhjdqboxifxmhalfmrmlursrqhrxse` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qvalpefxiifptyjjevnmtzdcmqtdwdxggesa` (`active`),
  KEY `idx_hbdyikrbjmnykwsgzabnhkuulpiwrkzgbhyn` (`locked`),
  KEY `idx_ialzkamnhyksmeilrxsbejdfmeazbwyqmssf` (`pending`),
  KEY `idx_tkadhqphcczkdfazuhmnkyvbggoihqrphcni` (`suspended`),
  KEY `idx_lysshvvqphfxurxyberaxmadntwvcjnchsqj` (`verificationCode`),
  KEY `idx_tyilfdynglycftgpylaukwhlzhyydiufetva` (`email`),
  KEY `idx_wszhagnawejbxxuzmcztuzclaesfvkuslhuv` (`username`),
  KEY `fk_fcbbpxabnuajnlvceemjjuiyhjynslrzyxid` (`photoId`),
  CONSTRAINT `fk_fcbbpxabnuajnlvceemjjuiyhjynslrzyxid` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_jhzkcviejbkawpeokjzknhchmgihbyhrlrtv` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pqafhikyfouoyjlhxkgzrrvjrqbaztsowrao` (`name`,`parentId`,`volumeId`),
  KEY `idx_gilsplwkdsrsedusyxweoemcdpnqlxbgxdpg` (`parentId`),
  KEY `idx_ksuedpjwbgxgthtwbcwxeejozztayafszhnc` (`volumeId`),
  CONSTRAINT `fk_vyunhvumieivndwzvklkebntutngjoxsrkhy` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xuxumnmlhyheqmjixfkrtwwlvgwwbbzqzetj` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xniihspzfigeazxmybtwvrphozfowmmupzut` (`name`),
  KEY `idx_jlcugrajwmlkjyjfedmejsnbvkyyvpgcigfr` (`handle`),
  KEY `idx_wlpbpujpqnrgmphkfsjajeamuuyijjrvwllh` (`fieldLayoutId`),
  KEY `idx_zniwecxaajzhggavqensmjdozazzvcyimfsb` (`dateDeleted`),
  CONSTRAINT `fk_oqenulaguqmlrllxffuqngicivunlvvmzozy` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_mtorzyrzycyayekdzlnepsdffoavhbgcilkp` (`userId`),
  CONSTRAINT `fk_mtorzyrzycyayekdzlnepsdffoavhbgcilkp` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wbcxkjclvtejvulybkemzkaesvkmxrsghvbr` (`userId`),
  CONSTRAINT `fk_flmyosjtbkerznxxbsistilojwqfrdhjhmls` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-25 13:31:33
-- MySQL dump 10.13  Distrib 8.0.36, for Linux (aarch64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets` VALUES (9,1,1,1,'Frame-1-1.png','image',NULL,592,333,423103,NULL,1,1,'2024-11-25 00:02:20','2024-11-25 00:02:20','2024-11-25 00:02:20'),(10,1,1,1,'Frame-1.png','image',NULL,592,333,268527,NULL,1,1,'2024-11-25 00:10:25','2024-11-25 00:02:20','2024-11-25 00:10:25'),(13,1,1,1,'Frame-1_2024-11-25-001022_gatu.png','image',NULL,592,333,268527,NULL,0,0,'2024-11-25 00:10:22','2024-11-25 00:10:22','2024-11-25 00:10:22'),(14,1,1,1,'tree-736885_1280.jpg','image',NULL,1280,797,185405,NULL,1,1,'2024-11-25 00:22:41','2024-11-25 00:11:06','2024-11-25 00:22:42'),(17,1,1,1,'tree-736885_1280_2024-11-25-002238_qzuv.jpg','image',NULL,1280,797,185405,NULL,0,0,'2024-11-25 00:22:38','2024-11-25 00:22:38','2024-11-25 00:22:38'),(18,2,4,1,'tree-736885_1280.jpg','image',NULL,1280,797,185405,NULL,NULL,NULL,'2024-11-25 00:31:16','2024-11-25 00:31:16','2024-11-25 00:31:16'),(54,2,4,1,'Frame-1-1.png','image',NULL,592,333,423103,NULL,NULL,NULL,'2024-11-25 06:46:06','2024-11-25 06:46:06','2024-11-25 06:46:06'),(55,2,4,1,'Frame-1.png','image',NULL,592,333,268527,NULL,NULL,NULL,'2024-11-25 06:46:13','2024-11-25 06:46:13','2024-11-25 06:46:13');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets_sites` VALUES (9,1,NULL),(10,1,NULL),(13,1,NULL),(14,1,NULL),(17,1,NULL),(18,1,NULL),(54,1,NULL),(55,1,NULL);
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `categorygroups` VALUES (1,1,5,'News','news','end','2024-11-25 06:06:12','2024-11-25 06:06:12',NULL,'d6ff0fc5-e079-4122-aee6-b52245a026e7');
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `categorygroups_sites` VALUES (1,1,1,1,'news/{slug}','news/_category.twig','2024-11-25 06:06:12','2024-11-25 06:06:12','84e9f5d7-42d4-487e-93c5-91b435a951fa');
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedattributes` VALUES (6,1,'postDate','2024-11-24 21:31:16',0,1),(6,1,'slug','2024-11-25 06:46:41',0,1),(6,1,'title','2024-11-25 06:46:41',0,1),(6,1,'uri','2024-11-24 21:31:12',0,1),(20,1,'postDate','2024-11-25 01:21:01',0,1),(20,1,'slug','2024-11-25 06:47:38',0,1),(20,1,'title','2024-11-25 06:47:38',0,1),(20,1,'uri','2024-11-25 01:20:48',0,1),(26,1,'postDate','2024-11-25 02:53:10',0,1),(26,1,'slug','2024-11-25 06:48:39',0,1),(26,1,'title','2024-11-25 06:48:39',0,1),(26,1,'uri','2024-11-25 02:52:58',0,1),(33,1,'postDate','2024-11-25 03:44:52',0,1),(33,1,'slug','2024-11-25 06:49:12',0,1),(33,1,'title','2024-11-25 06:49:12',0,1),(33,1,'uri','2024-11-25 03:44:33',0,1),(35,1,'postDate','2024-11-25 03:45:09',0,1),(35,1,'slug','2024-11-25 06:49:57',0,1),(35,1,'title','2024-11-25 06:49:57',0,1),(35,1,'uri','2024-11-25 03:45:06',0,1),(37,1,'postDate','2024-11-25 03:45:19',0,1),(37,1,'slug','2024-11-25 06:50:34',0,1),(37,1,'title','2024-11-25 06:50:34',0,1),(37,1,'uri','2024-11-25 03:45:13',0,1),(40,1,'postDate','2024-11-25 03:45:34',0,1),(40,1,'slug','2024-11-25 06:30:17',0,1),(40,1,'title','2024-11-25 06:30:17',0,1),(40,1,'uri','2024-11-25 03:45:26',0,1),(133,1,'postDate','2024-11-25 11:11:02',0,1),(133,1,'slug','2024-11-25 11:10:29',0,1),(133,1,'title','2024-11-25 11:10:29',0,1),(133,1,'uri','2024-11-25 11:10:29',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedfields` VALUES (6,1,1,'4aa92777-c4a7-4baa-8904-d92f9e085fb6','2024-11-25 02:52:48',0,1),(6,1,2,'8543a8ed-d05a-4df4-90d0-df04c2b06519','2024-11-25 06:46:41',0,1),(6,1,3,'735b9e7b-1762-4b48-89f1-5416895bd6d3','2024-11-25 06:47:45',0,1),(6,1,5,'9dae6c46-66cf-472c-b670-d6da3fe8e56f','2024-11-25 06:55:56',0,1),(20,1,1,'4aa92777-c4a7-4baa-8904-d92f9e085fb6','2024-11-25 01:21:01',0,1),(20,1,2,'8543a8ed-d05a-4df4-90d0-df04c2b06519','2024-11-25 06:47:38',0,1),(20,1,3,'735b9e7b-1762-4b48-89f1-5416895bd6d3','2024-11-25 06:47:38',0,1),(26,1,1,'4aa92777-c4a7-4baa-8904-d92f9e085fb6','2024-11-25 02:53:10',0,1),(26,1,2,'8543a8ed-d05a-4df4-90d0-df04c2b06519','2024-11-25 06:48:39',0,1),(26,1,3,'735b9e7b-1762-4b48-89f1-5416895bd6d3','2024-11-25 06:48:39',0,1),(26,1,5,'9dae6c46-66cf-472c-b670-d6da3fe8e56f','2024-11-25 06:56:01',0,1),(33,1,1,'4aa92777-c4a7-4baa-8904-d92f9e085fb6','2024-11-25 03:44:52',0,1),(33,1,2,'8543a8ed-d05a-4df4-90d0-df04c2b06519','2024-11-25 06:49:23',0,1),(33,1,3,'735b9e7b-1762-4b48-89f1-5416895bd6d3','2024-11-25 06:49:12',0,1),(33,1,5,'9dae6c46-66cf-472c-b670-d6da3fe8e56f','2024-11-25 06:56:31',0,1),(35,1,2,'8543a8ed-d05a-4df4-90d0-df04c2b06519','2024-11-25 06:49:57',0,1),(35,1,3,'735b9e7b-1762-4b48-89f1-5416895bd6d3','2024-11-25 06:49:57',0,1),(35,1,5,'9dae6c46-66cf-472c-b670-d6da3fe8e56f','2024-11-25 06:56:27',0,1),(37,1,2,'8543a8ed-d05a-4df4-90d0-df04c2b06519','2024-11-25 06:50:45',0,1),(37,1,3,'735b9e7b-1762-4b48-89f1-5416895bd6d3','2024-11-25 06:50:34',0,1),(37,1,5,'9dae6c46-66cf-472c-b670-d6da3fe8e56f','2024-11-25 04:46:02',0,1),(40,1,1,'4aa92777-c4a7-4baa-8904-d92f9e085fb6','2024-11-25 08:16:04',0,1),(40,1,2,'8543a8ed-d05a-4df4-90d0-df04c2b06519','2024-11-25 09:30:08',0,1),(40,1,3,'735b9e7b-1762-4b48-89f1-5416895bd6d3','2024-11-25 10:11:29',0,1),(40,1,5,'9dae6c46-66cf-472c-b670-d6da3fe8e56f','2024-11-25 04:21:34',0,1),(40,1,8,'bf470c7f-7dc5-4e40-a119-ff14f27a0d73','2024-11-25 08:28:17',0,1),(90,1,1,'9d42365a-b6cc-4efa-9e21-75d0485f4e2e','2024-11-25 08:16:01',0,1),(90,1,9,'e5c64962-e6a2-4fe2-89dc-08babd909c58','2024-11-25 10:11:10',0,1),(90,1,15,'e135c047-9b8d-4aa0-990f-1bc9a5bf96c2','2024-11-25 09:41:35',0,1),(101,1,9,'82ca84f7-6361-4afc-99ce-7d1001f0544b','2024-11-25 10:10:23',0,1),(101,1,10,'3cba98e0-5c15-4a0f-939b-18e23cdd05fb','2024-11-25 10:50:10',0,1),(101,1,11,'90d47f07-a348-4cf6-b54c-52b94b7e3b2c','2024-11-25 10:50:10',0,1),(101,1,12,'ee4daa79-ca03-488a-b6ff-87f6f1f057c9','2024-11-25 08:29:02',0,1),(101,1,14,'123618a8-a467-4088-9650-e69f816449f6','2024-11-25 09:43:39',0,1),(133,1,2,'8543a8ed-d05a-4df4-90d0-df04c2b06519','2024-11-25 11:11:02',0,1),(133,1,3,'735b9e7b-1762-4b48-89f1-5416895bd6d3','2024-11-25 11:11:02',0,1),(133,1,5,'9dae6c46-66cf-472c-b670-d6da3fe8e56f','2024-11-25 11:11:02',0,1),(133,1,8,'bf470c7f-7dc5-4e40-a119-ff14f27a0d73','2024-11-25 11:13:07',0,1),(137,1,15,'e135c047-9b8d-4aa0-990f-1bc9a5bf96c2','2024-11-25 13:07:48',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `drafts` VALUES (1,NULL,1,0,'First draft',NULL,0,NULL,1),(2,NULL,1,0,'First draft',NULL,0,NULL,1),(38,NULL,1,0,'First draft',NULL,0,NULL,0),(39,NULL,1,0,'First draft',NULL,0,NULL,0);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elementactivity` VALUES (6,1,1,NULL,'edit','2024-11-25 06:55:51'),(6,1,1,NULL,'save','2024-11-25 06:55:56'),(20,1,1,NULL,'edit','2024-11-25 06:47:38'),(20,1,1,NULL,'save','2024-11-25 06:47:38'),(26,1,1,NULL,'edit','2024-11-25 06:55:59'),(26,1,1,NULL,'save','2024-11-25 06:56:01'),(33,1,1,NULL,'edit','2024-11-25 06:56:30'),(33,1,1,NULL,'save','2024-11-25 06:56:31'),(35,1,1,NULL,'edit','2024-11-25 06:56:25'),(35,1,1,NULL,'save','2024-11-25 06:56:27'),(37,1,1,NULL,'edit','2024-11-25 06:50:44'),(37,1,1,NULL,'save','2024-11-25 06:50:45'),(40,1,1,NULL,'edit','2024-11-25 10:11:28'),(40,1,1,NULL,'save','2024-11-25 10:11:29'),(90,1,1,NULL,'edit','2024-11-25 10:11:09'),(90,1,1,NULL,'save','2024-11-25 10:49:51'),(101,1,1,NULL,'edit','2024-11-25 10:50:10'),(101,1,1,NULL,'save','2024-11-25 10:50:10'),(133,1,1,NULL,'edit','2024-11-25 11:12:02'),(133,1,1,NULL,'save','2024-11-25 13:07:49'),(137,1,1,NULL,'edit','2024-11-25 13:07:47'),(137,1,1,NULL,'save','2024-11-25 13:07:48');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-11-24 20:04:52','2024-11-24 20:04:52',NULL,NULL,NULL,'25f937a4-a507-4c3f-b691-9f27fcc2731a'),(2,NULL,1,NULL,1,'craft\\elements\\Entry',1,0,'2024-11-24 20:10:49','2024-11-25 06:44:39',NULL,'2024-11-25 06:44:39',NULL,'3db9c960-8adf-436c-9119-9538c953bb2b'),(3,NULL,2,NULL,1,'craft\\elements\\Entry',1,0,'2024-11-24 20:46:07','2024-11-25 06:44:39',NULL,'2024-11-25 06:44:39',NULL,'8aedd9dd-daf1-4ea1-9216-687257425903'),(4,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-11-24 21:00:08','2024-11-25 10:59:54',NULL,NULL,NULL,'5cc347cf-25bd-41e8-a042-8e285b5c3793'),(5,4,NULL,1,2,'craft\\elements\\Entry',1,0,'2024-11-24 21:00:08','2024-11-24 21:00:08',NULL,NULL,NULL,'9efa7bca-01f4-47db-a78d-19c7e1ff5336'),(6,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-11-24 21:31:07','2024-11-25 06:55:56',NULL,NULL,NULL,'deef4095-7799-4960-8a82-f02ff47478a5'),(7,6,NULL,2,1,'craft\\elements\\Entry',1,0,'2024-11-24 21:31:16','2024-11-24 21:31:16',NULL,NULL,NULL,'95e3b9f7-dd79-439b-8651-ef5aaf49ecde'),(9,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-11-25 00:02:20','2024-11-25 00:22:55',NULL,'2024-11-25 00:22:55',NULL,'427eabeb-d982-4eea-90a7-465d9b99b527'),(10,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-11-25 00:02:20','2024-11-25 00:22:55',NULL,'2024-11-25 00:22:55',NULL,'ccc194f4-cf82-4c4a-b514-9f82ae7fbee4'),(11,6,NULL,3,1,'craft\\elements\\Entry',1,0,'2024-11-25 00:02:33','2024-11-25 00:02:33',NULL,NULL,NULL,'50300f03-4176-4c2f-92d4-278394fc8a1a'),(13,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-11-25 00:10:22','2024-11-25 00:10:25',NULL,'2024-11-25 00:10:25',NULL,'56f8491b-09d7-4c67-968d-ca00e4fcea45'),(14,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-11-25 00:11:06','2024-11-25 00:22:55',NULL,'2024-11-25 00:22:55',NULL,'cf4ce8dc-cac9-48e7-9c58-8241a9a68768'),(15,6,NULL,4,1,'craft\\elements\\Entry',1,0,'2024-11-25 00:11:18','2024-11-25 00:11:18',NULL,NULL,NULL,'b80c6471-3782-45cf-a510-9d21d6002153'),(17,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-11-25 00:22:38','2024-11-25 00:22:42',NULL,'2024-11-25 00:22:42',NULL,'d121870c-f9ad-4bdf-98a7-4c5d4916019e'),(18,NULL,NULL,NULL,4,'craft\\elements\\Asset',1,0,'2024-11-25 00:31:16','2024-11-25 00:31:16',NULL,NULL,NULL,'7b01fb83-d23b-4fb8-803c-9e329ad031fa'),(19,6,NULL,5,1,'craft\\elements\\Entry',1,0,'2024-11-25 00:31:23','2024-11-25 00:31:23',NULL,NULL,NULL,'c4b646f2-4fe5-482d-be91-a97fada78617'),(20,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-11-25 01:20:43','2024-11-25 06:47:38',NULL,NULL,NULL,'cb38903d-8272-4e33-8759-c059b461f851'),(21,20,NULL,6,1,'craft\\elements\\Entry',1,0,'2024-11-25 01:21:01','2024-11-25 01:21:01',NULL,NULL,NULL,'9c601ff2-d082-434b-85c5-3954b10c7992'),(23,6,NULL,7,1,'craft\\elements\\Entry',1,0,'2024-11-25 01:37:33','2024-11-25 01:37:33',NULL,NULL,NULL,'780da95c-0432-4f71-977d-5460f99c4ce1'),(25,6,NULL,8,1,'craft\\elements\\Entry',1,0,'2024-11-25 02:52:48','2024-11-25 02:52:48',NULL,NULL,NULL,'3e693157-87fa-49d9-b443-884ffdea0722'),(26,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-11-25 02:52:51','2024-11-25 06:56:01',NULL,NULL,NULL,'914bc958-6a09-4e12-8e49-ab8eba500256'),(27,26,NULL,9,1,'craft\\elements\\Entry',1,0,'2024-11-25 02:53:10','2024-11-25 02:53:10',NULL,NULL,NULL,'7b682878-b10c-46dd-b5fe-4bc13de3ad17'),(29,6,NULL,10,1,'craft\\elements\\Entry',1,0,'2024-11-25 03:20:53','2024-11-25 03:20:53',NULL,NULL,NULL,'edc55411-3637-4f88-afe5-cbc62f1a3327'),(30,20,NULL,11,1,'craft\\elements\\Entry',1,0,'2024-11-25 03:20:59','2024-11-25 03:20:59',NULL,NULL,NULL,'145b4f29-e256-42a7-984d-b45376b73a97'),(32,26,NULL,12,1,'craft\\elements\\Entry',1,0,'2024-11-25 03:21:04','2024-11-25 03:21:04',NULL,NULL,NULL,'ed8c963d-e04d-4e8f-ab51-5c422707caaa'),(33,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-11-25 03:44:27','2024-11-25 06:56:31',NULL,NULL,NULL,'2d14d313-eae9-41c4-a217-5e3155d0aeb4'),(34,33,NULL,13,1,'craft\\elements\\Entry',1,0,'2024-11-25 03:44:52','2024-11-25 03:44:52',NULL,NULL,NULL,'7bcf04bd-be4a-4b15-af5c-198fa60e6b80'),(35,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-11-25 03:44:54','2024-11-25 06:56:27',NULL,NULL,NULL,'3e152905-a6a1-4268-be7e-d4820c03f5a2'),(36,35,NULL,14,1,'craft\\elements\\Entry',1,0,'2024-11-25 03:45:09','2024-11-25 03:45:09',NULL,NULL,NULL,'69cd36de-fa92-4ba6-906b-5d4875e4fecb'),(37,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-11-25 03:45:09','2024-11-25 06:50:45',NULL,NULL,NULL,'d098d0ca-f431-453e-ae87-f93dc211ecb7'),(38,37,NULL,15,1,'craft\\elements\\Entry',1,0,'2024-11-25 03:45:19','2024-11-25 03:45:19',NULL,NULL,NULL,'3f8f3166-4e6e-4d2d-8cd8-50c2e6ce5ef5'),(39,37,NULL,16,1,'craft\\elements\\Entry',1,0,'2024-11-25 03:45:20','2024-11-25 03:45:21',NULL,NULL,NULL,'c0671ee1-3374-4e52-a505-4ece69bf76b0'),(40,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-11-25 03:45:21','2024-11-25 10:11:29',NULL,NULL,NULL,'a8387459-3824-4901-bb7d-11c319c28d49'),(41,40,NULL,17,1,'craft\\elements\\Entry',1,0,'2024-11-25 03:45:34','2024-11-25 03:45:34',NULL,NULL,NULL,'9fe6711e-da2d-499a-b0a8-dfad2767c3dd'),(43,40,NULL,18,1,'craft\\elements\\Entry',1,0,'2024-11-25 04:21:34','2024-11-25 04:21:34',NULL,NULL,NULL,'6beafea5-ec14-4efc-bc6d-a1df3c7e8509'),(45,40,NULL,19,1,'craft\\elements\\Entry',1,0,'2024-11-25 04:25:27','2024-11-25 04:25:27',NULL,NULL,NULL,'886c76eb-0620-428e-a745-882dda158a57'),(47,37,NULL,20,1,'craft\\elements\\Entry',1,0,'2024-11-25 04:46:02','2024-11-25 04:46:02',NULL,NULL,NULL,'b2fc1f48-db39-4543-bf55-93af1f5be844'),(49,40,NULL,21,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:30:17','2024-11-25 06:30:17',NULL,NULL,NULL,'474da603-af32-4a2e-8ae5-7a6db30839cc'),(50,6,NULL,22,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:35:03','2024-11-25 06:35:03',NULL,NULL,NULL,'f0ad90a2-bb1b-4a99-8dae-933a091d00ef'),(52,37,NULL,23,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:44:01','2024-11-25 06:44:01',NULL,NULL,NULL,'a1a256b4-b01e-4f67-8c48-764620676302'),(54,NULL,NULL,NULL,4,'craft\\elements\\Asset',1,0,'2024-11-25 06:46:06','2024-11-25 06:46:06',NULL,NULL,NULL,'5dce206f-caff-494f-a2ef-338104ded2ec'),(55,NULL,NULL,NULL,4,'craft\\elements\\Asset',1,0,'2024-11-25 06:46:13','2024-11-25 06:46:13',NULL,NULL,NULL,'6e9db341-f273-48c1-aed5-d28e8ce69a12'),(56,6,NULL,24,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:46:41','2024-11-25 06:46:41',NULL,NULL,NULL,'050a197f-8192-48a4-8159-2d8bc6a3e9fd'),(58,20,NULL,25,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:47:38','2024-11-25 06:47:38',NULL,NULL,NULL,'7d228db7-39d3-4b7b-924e-f0949dbf4dca'),(60,6,NULL,26,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:47:45','2024-11-25 06:47:45',NULL,NULL,NULL,'be0da1b2-0bdd-4afb-a783-3d5c958afc86'),(62,26,NULL,27,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:48:39','2024-11-25 06:48:39',NULL,NULL,NULL,'b6271e70-bd81-410d-a4a3-a05144781179'),(64,33,NULL,28,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:49:12','2024-11-25 06:49:12',NULL,NULL,NULL,'e433dfcb-2929-4fcc-a125-7e253020e805'),(66,33,NULL,29,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:49:23','2024-11-25 06:49:23',NULL,NULL,NULL,'52def171-3ec4-46bb-be15-5b2be5bdf0bc'),(68,35,NULL,30,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:49:57','2024-11-25 06:49:57',NULL,NULL,NULL,'7e2ad64a-a35a-42e1-96e8-536e07ebf761'),(70,37,NULL,31,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:50:34','2024-11-25 06:50:34',NULL,NULL,NULL,'f091c299-4fed-4434-b7cc-d6678a338e3e'),(72,37,NULL,32,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:50:45','2024-11-25 06:50:45',NULL,NULL,NULL,'71663364-4784-4cab-9b3c-7da1e7d13b73'),(74,6,NULL,33,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:55:56','2024-11-25 06:55:56',NULL,NULL,NULL,'70b1af03-6556-4f76-8f98-7f7a5d5b3b06'),(76,26,NULL,34,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:56:01','2024-11-25 06:56:01',NULL,NULL,NULL,'2677f1f5-ae2b-415f-8bd4-0af516ec347d'),(77,40,NULL,35,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:56:04','2024-11-25 06:56:04',NULL,NULL,NULL,'b7065b33-4f98-495e-9006-0a7e314807cd'),(79,35,NULL,36,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:56:27','2024-11-25 06:56:27',NULL,NULL,NULL,'61d8f821-b2b4-466f-864c-59edb9eeb68b'),(81,33,NULL,37,1,'craft\\elements\\Entry',1,0,'2024-11-25 06:56:31','2024-11-25 06:56:31',NULL,NULL,NULL,'33af906b-11c4-45ed-a7dd-1e9281f82220'),(83,40,NULL,38,1,'craft\\elements\\Entry',1,0,'2024-11-25 07:21:28','2024-11-25 07:21:28',NULL,NULL,NULL,'4f1d9d5c-625c-4034-8a8a-c076d8f03186'),(85,40,NULL,39,1,'craft\\elements\\Entry',1,0,'2024-11-25 07:21:45','2024-11-25 07:21:45',NULL,NULL,NULL,'989428c4-9ed7-4898-8024-9b76a21852a5'),(87,NULL,38,NULL,8,'craft\\elements\\Entry',1,0,'2024-11-25 08:06:03','2024-11-25 08:06:03',NULL,NULL,NULL,'543e09c6-d1a6-4101-9ab6-3da33c596eef'),(88,NULL,39,NULL,7,'craft\\elements\\Entry',1,0,'2024-11-25 08:06:18','2024-11-25 08:06:18',NULL,NULL,NULL,'340a9440-c7ca-4038-83b5-6363319e50ea'),(90,NULL,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2024-11-25 08:07:01','2024-11-25 10:49:51',NULL,NULL,NULL,'c456a0f1-a518-448d-bff1-8aaef28e7782'),(91,40,NULL,40,1,'craft\\elements\\Entry',1,0,'2024-11-25 08:07:01','2024-11-25 08:07:01',NULL,NULL,NULL,'f0a85b12-d514-4fdc-902b-5a7b472859cb'),(92,90,NULL,41,8,'craft\\elements\\Entry',1,0,'2024-11-25 08:07:01','2024-11-25 08:07:01',NULL,NULL,NULL,'412dac0c-608a-4e34-935c-29144b45bb08'),(95,40,NULL,42,1,'craft\\elements\\Entry',1,0,'2024-11-25 08:16:04','2024-11-25 08:16:04',NULL,NULL,NULL,'a55e58c7-3163-43d6-8fc7-427c59da21f7'),(96,90,NULL,43,8,'craft\\elements\\Entry',1,0,'2024-11-25 08:16:01','2024-11-25 08:16:04',NULL,NULL,NULL,'ba1a0787-6561-4900-b951-efe0c140f576'),(97,40,NULL,44,1,'craft\\elements\\Entry',1,0,'2024-11-25 08:18:19','2024-11-25 08:18:19',NULL,NULL,NULL,'1434a500-cacf-400c-97b2-766adcbcb900'),(98,90,NULL,45,8,'craft\\elements\\Entry',1,0,'2024-11-25 08:18:17','2024-11-25 08:18:19',NULL,NULL,NULL,'3b8fa176-bb09-43fc-94df-6d84eea483bd'),(101,NULL,NULL,NULL,7,'craft\\elements\\Entry',1,0,'2024-11-25 08:28:17','2024-11-25 10:50:10',NULL,NULL,NULL,'444d5cd2-ab3a-4c84-aabe-8a9dd35347f7'),(102,40,NULL,46,1,'craft\\elements\\Entry',1,0,'2024-11-25 08:28:17','2024-11-25 08:28:17',NULL,NULL,NULL,'1ea88ced-54dc-4f6c-8232-2c45d3eb66bd'),(103,101,NULL,47,7,'craft\\elements\\Entry',1,0,'2024-11-25 08:28:17','2024-11-25 08:28:17',NULL,NULL,NULL,'67284de2-1a8f-43cd-8ee0-89dd135548a8'),(105,40,NULL,48,1,'craft\\elements\\Entry',1,0,'2024-11-25 08:29:03','2024-11-25 08:29:03',NULL,NULL,NULL,'7ff097ca-2676-497e-9215-032653ce1720'),(106,101,NULL,49,7,'craft\\elements\\Entry',1,0,'2024-11-25 08:29:02','2024-11-25 08:29:03',NULL,NULL,NULL,'65774d7c-adc7-4ea3-9ce7-1c11207f780d'),(108,40,NULL,50,1,'craft\\elements\\Entry',1,0,'2024-11-25 09:30:08','2024-11-25 09:30:08',NULL,NULL,NULL,'984b22fc-296a-4824-8ed8-2ccf3b6b767f'),(109,101,NULL,51,7,'craft\\elements\\Entry',1,0,'2024-11-25 09:29:55','2024-11-25 09:30:08',NULL,NULL,NULL,'b6a9b079-cd23-426f-8fc4-e25854ada165'),(111,40,NULL,52,1,'craft\\elements\\Entry',1,0,'2024-11-25 09:41:36','2024-11-25 09:41:36',NULL,NULL,NULL,'791bcb5f-d133-418b-8e47-5ba99e07d75c'),(112,90,NULL,53,8,'craft\\elements\\Entry',1,0,'2024-11-25 09:41:35','2024-11-25 09:41:36',NULL,NULL,NULL,'b3d8a009-2d51-4bc6-a487-02c71f95082f'),(114,40,NULL,54,1,'craft\\elements\\Entry',1,0,'2024-11-25 09:47:28','2024-11-25 09:47:28',NULL,NULL,NULL,'51396520-7c7a-4def-b2dc-a17bc2ac1e73'),(115,90,NULL,55,8,'craft\\elements\\Entry',1,0,'2024-11-25 09:47:27','2024-11-25 09:47:28',NULL,NULL,NULL,'8f330c95-4ae7-4cc2-8ef6-cf421cca5fb5'),(116,101,NULL,56,7,'craft\\elements\\Entry',1,0,'2024-11-25 09:43:39','2024-11-25 09:47:28',NULL,NULL,NULL,'50160acb-3976-4d18-a2c0-c3683f4cdfb3'),(118,40,NULL,57,1,'craft\\elements\\Entry',1,0,'2024-11-25 09:47:54','2024-11-25 09:47:54',NULL,NULL,NULL,'3ce55299-6b11-4e6c-bd37-a70668f15a14'),(119,90,NULL,58,8,'craft\\elements\\Entry',1,0,'2024-11-25 09:47:52','2024-11-25 09:47:54',NULL,NULL,NULL,'6cb95f1b-0c9e-44b5-8f51-f999696f25f5'),(120,40,NULL,59,1,'craft\\elements\\Entry',1,0,'2024-11-25 09:48:35','2024-11-25 09:48:35',NULL,NULL,NULL,'0bd56475-a4c0-4234-8dad-761890aefd96'),(123,40,NULL,60,1,'craft\\elements\\Entry',1,0,'2024-11-25 10:10:34','2024-11-25 10:10:34',NULL,NULL,NULL,'10a6d87e-1d40-482d-8054-8925b84f9fbb'),(124,101,NULL,61,7,'craft\\elements\\Entry',1,0,'2024-11-25 10:10:32','2024-11-25 10:10:34',NULL,NULL,NULL,'700fd00c-e09b-490a-a293-513c5052aa81'),(126,40,NULL,62,1,'craft\\elements\\Entry',1,0,'2024-11-25 10:11:12','2024-11-25 10:11:12',NULL,NULL,NULL,'580cfa37-48ab-48c9-81f8-c045f58258c6'),(127,90,NULL,63,8,'craft\\elements\\Entry',1,0,'2024-11-25 10:11:10','2024-11-25 10:11:12',NULL,NULL,NULL,'0c467159-796f-45f9-8320-7bd3bc677113'),(129,40,NULL,64,1,'craft\\elements\\Entry',1,0,'2024-11-25 10:11:29','2024-11-25 10:11:29',NULL,NULL,NULL,'b992e26f-0949-490f-8763-0452aa426dbc'),(132,4,NULL,65,2,'craft\\elements\\Entry',1,0,'2024-11-25 10:59:54','2024-11-25 10:59:54',NULL,NULL,NULL,'51b71e4c-a275-4083-8441-8104fd089c5d'),(133,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-11-25 11:10:15','2024-11-25 13:07:49',NULL,NULL,NULL,'d626c037-e37a-4ff8-8157-05fcd2c39473'),(134,133,NULL,66,1,'craft\\elements\\Entry',1,0,'2024-11-25 11:11:02','2024-11-25 11:11:02',NULL,NULL,NULL,'5e5cb36a-b009-4a04-8ff6-993ab467e77b'),(137,NULL,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2024-11-25 11:13:07','2024-11-25 13:07:48',NULL,NULL,NULL,'ac2de82e-3386-4724-981c-fef7144a8e00'),(138,133,NULL,67,1,'craft\\elements\\Entry',1,0,'2024-11-25 11:13:07','2024-11-25 11:13:07',NULL,NULL,NULL,'cb1c1f6d-8980-4594-84bc-150121d85d95'),(139,137,NULL,68,8,'craft\\elements\\Entry',1,0,'2024-11-25 11:13:07','2024-11-25 11:13:07',NULL,NULL,NULL,'6dabd9af-6a2b-4ab7-a5b8-4dd74856b9fa'),(141,133,NULL,69,1,'craft\\elements\\Entry',1,0,'2024-11-25 13:07:49','2024-11-25 13:07:49',NULL,NULL,NULL,'7c0c2d25-ea90-44c6-850a-838fe08222f0'),(142,137,NULL,70,8,'craft\\elements\\Entry',1,0,'2024-11-25 13:07:48','2024-11-25 13:07:49',NULL,NULL,NULL,'7156c698-1b88-4133-a87d-f78ccc3a284c');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_owners` VALUES (90,40,1),(92,91,3),(96,95,3),(98,97,3),(98,102,1),(98,105,1),(98,108,1),(101,40,2),(103,102,2),(106,105,2),(109,108,2),(109,111,2),(112,111,1),(115,114,1),(116,114,2),(116,118,2),(116,120,2),(119,118,1),(119,120,1),(119,123,1),(124,123,2),(124,126,2),(124,129,2),(127,126,1),(127,129,1),(137,133,1),(139,138,1),(142,141,1);
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2024-11-24 20:04:52','2024-11-24 20:04:52','5e333970-2183-428b-bac2-07f30f71a78d'),(2,2,1,NULL,'__temp_dmxflwzobuejpsfewxzkdbsbjicilehwuijm','news/__temp_dmxflwzobuejpsfewxzkdbsbjicilehwuijm','{\"8543a8ed-d05a-4df4-90d0-df04c2b06519\": []}',1,'2024-11-24 20:10:49','2024-11-25 06:32:02','507be90a-90fa-4806-ad47-dc1949550d25'),(3,3,1,NULL,'__temp_hwjjeudtemnlcfpjmjlbtivxusbedccnyvls','news/__temp_hwjjeudtemnlcfpjmjlbtivxusbedccnyvls','{\"8543a8ed-d05a-4df4-90d0-df04c2b06519\": []}',1,'2024-11-24 20:46:07','2024-11-25 06:32:02','f04ed4b7-affe-4990-98a9-f957ecd945c1'),(4,4,1,'Homepage','homepage','homepage',NULL,1,'2024-11-24 21:00:08','2024-11-24 21:00:08','f41c6f16-7246-4f25-89c7-3da1ec75651f'),(5,5,1,'Homepage','homepage','homepage',NULL,1,'2024-11-24 21:00:08','2024-11-24 21:00:08','226bb6bb-b2ff-4e14-ac42-8353d89f38b0'),(6,6,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-24 21:31:07','2024-11-25 06:55:56','bb3201a2-bbe9-46b7-83f4-d1182c54e381'),(7,7,1,'Test Artticle','test-artticle','articles/test-artticle','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"Test\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": []}',1,'2024-11-24 21:31:16','2024-11-25 06:32:02','a3abcfe4-0b9b-4527-98be-d5664c776287'),(9,9,1,'Frame 1 1',NULL,NULL,NULL,1,'2024-11-25 00:02:20','2024-11-25 00:02:20','a55cf994-af95-4bf4-bc96-daf406e6cdc7'),(10,10,1,'Frame 1',NULL,NULL,NULL,1,'2024-11-25 00:02:20','2024-11-25 00:02:20','182f5885-de6f-4c1c-b0c2-6fcf2ca3bf6a'),(11,11,1,'Test Article','test-artticle','articles/test-artticle','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"Test\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": []}',1,'2024-11-25 00:02:33','2024-11-25 06:32:02','2f09ee95-0d0f-4fe5-b819-b82ef1ca25b5'),(13,13,1,'Frame 1',NULL,NULL,NULL,1,'2024-11-25 00:10:22','2024-11-25 00:10:22','e70f44f3-00ca-40f0-9073-59f8e5cc3e71'),(14,14,1,'Tree 736885 1280',NULL,NULL,NULL,1,'2024-11-25 00:11:06','2024-11-25 00:11:06','987bcdac-509a-4e3f-aad7-e3c2a2fd2551'),(15,15,1,'Test Article','test-artticle','articles/test-artticle','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"Test\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": []}',1,'2024-11-25 00:11:18','2024-11-25 06:32:02','523d6fa3-a9e1-4007-8ec9-da64db1d9d62'),(17,17,1,'Tree 736885 1280',NULL,NULL,NULL,1,'2024-11-25 00:22:38','2024-11-25 00:22:38','8d274da7-fc96-43ff-94db-8af23516c7f7'),(18,18,1,'Tree 736885 1280',NULL,NULL,NULL,1,'2024-11-25 00:31:16','2024-11-25 00:31:16','97a05c29-f271-44af-8361-49cac28bfada'),(19,19,1,'Test Article','test-artticle','articles/test-artticle','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"Test\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18]}',1,'2024-11-25 00:31:23','2024-11-25 00:31:23','7a1cd89e-4f02-4569-b19b-5b65ef498707'),(20,20,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-2','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-2','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>Lorem Ipsum</p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [54]}',1,'2024-11-25 01:20:43','2024-11-25 06:47:38','9050df03-cdb8-4ea3-8105-8adf93a24aeb'),(21,21,1,'Test Article 2','test-article-2','articles/test-article-2','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>Lorem Ipsum</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18]}',1,'2024-11-25 01:21:01','2024-11-25 01:21:01','b473b3cb-42ea-4c67-90c1-3df706e0f8a3'),(23,23,1,'Test Article','test-artticle','articles/test-artticle','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<h1>Test</h1>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18]}',1,'2024-11-25 01:37:33','2024-11-25 01:37:33','7ff0ecbc-02fe-40e3-b293-47f96ba1780f'),(25,25,1,'Test Article','test-artticle','articles/test-artticle','{\"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18]}',1,'2024-11-25 02:52:48','2024-11-25 02:52:48','60ee96ed-abca-4cc9-ae66-4e242a386a4e'),(26,26,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-3','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-3','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>anajbxjsbcasknxckcas</p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [54], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 02:52:51','2024-11-25 06:56:01','18b21c28-ee0b-45d0-a365-09a62caa9f23'),(27,27,1,'Test Article 3','test-article-3','articles/test-article-3','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>anajbxjsbcasknxckcas</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18]}',1,'2024-11-25 02:53:10','2024-11-25 02:53:10','87be7ccf-37a1-45be-a959-140eaeb6e425'),(29,29,1,'Test Article','test-artticle','articles/test-artticle','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18]}',1,'2024-11-25 03:20:53','2024-11-25 03:20:53','fa2aeb9a-7549-48eb-ab3b-554cf97b410d'),(30,30,1,'Test Article 2','test-article-2','articles/test-article-2','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>Lorem Ipsum</p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18]}',1,'2024-11-25 03:20:59','2024-11-25 03:20:59','2c5603ad-be34-4e86-862a-94480e4e3714'),(32,32,1,'Test Article 3','test-article-3','articles/test-article-3','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>anajbxjsbcasknxckcas</p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18]}',1,'2024-11-25 03:21:04','2024-11-25 03:21:04','8fea4b30-cdb7-4fc2-9f39-4013ecd15cdd'),(33,33,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-4','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-4','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>Test </p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"David Smith\"}',1,'2024-11-25 03:44:27','2024-11-25 06:56:31','cb3e79ed-4869-49f5-bcc1-4e6f0397d232'),(34,34,1,'Test Article 4','test-article-4','articles/test-article-4','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>Test </p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18]}',1,'2024-11-25 03:44:52','2024-11-25 03:44:52','b0942c48-0b03-4311-a038-851444176d21'),(35,35,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-5','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-5','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"David Smith\"}',1,'2024-11-25 03:44:54','2024-11-25 06:56:27','c1aa44ff-1ed9-4a31-b4cf-87f36a151d72'),(36,36,1,'Article 5','article-5','articles/article-5','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18]}',1,'2024-11-25 03:45:09','2024-11-25 03:45:09','b512da41-dccb-486a-803c-354b32cf7bf9'),(37,37,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-6','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-6','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [54], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 03:45:09','2024-11-25 06:50:45','295e8237-a560-4ae9-9695-a0146544321a'),(38,38,1,'Arictle 6','arictle-6','articles/arictle-6','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18]}',1,'2024-11-25 03:45:19','2024-11-25 03:45:19','0a4a09e1-7f9a-420c-b367-5a6ff0ad8c8a'),(39,39,1,'Arictle 6','arictle-6','articles/arictle-6','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18]}',1,'2024-11-25 03:45:21','2024-11-25 03:45:21','61961434-5684-43d1-9a3b-7276e44b27d4'),(40,40,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 03:45:21','2024-11-25 10:11:29','d4329508-5fbb-424d-90d5-086d587c9bbe'),(41,41,1,'Article 7','article-7','articles/article-7','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18]}',1,'2024-11-25 03:45:34','2024-11-25 03:45:34','9d00ad84-ef6b-4352-9f8f-fc885736248a'),(43,43,1,'Article 7','article-7','articles/article-7','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 04:21:34','2024-11-25 04:21:34','dda83190-0d0c-473a-8547-2fac45f37f7a'),(45,45,1,'Article 7','article-7','articles/article-7','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><h4>Where does it come from?</h4><p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \\\"de Finibus Bonorum et Malorum\\\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \\\"Lorem ipsum dolor sit amet..\\\", comes from a line in section 1.10.32.</p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 04:25:27','2024-11-25 04:25:27','8359f81f-9799-45e3-b848-a5129627cad1'),(47,47,1,'Arictle 6','arictle-6','articles/arictle-6','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 04:46:02','2024-11-25 04:46:02','bfb39b3f-8f5c-4f79-8e51-c122c95cc74b'),(49,49,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','articles/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><h4>Where does it come from?</h4><p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \\\"de Finibus Bonorum et Malorum\\\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \\\"Lorem ipsum dolor sit amet..\\\", comes from a line in section 1.10.32.</p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 06:30:17','2024-11-25 06:30:17','5632a8bc-a410-4a82-9d3a-3807e4460835'),(50,50,1,'Test Article','test-artticle','news/test-artticle','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18]}',1,'2024-11-25 06:35:03','2024-11-25 06:35:03','4da4b57b-7cd9-4a24-bd23-cf376ce63caf'),(52,52,1,'Article 6','article-6','news/article-6','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 06:44:01','2024-11-25 06:44:01','df421f8d-91ed-47b0-8e44-3fc1dfa4dcba'),(54,54,1,'Frame 1 1',NULL,NULL,NULL,1,'2024-11-25 06:46:06','2024-11-25 06:46:06','983515da-2a4e-4378-b95c-83d081684864'),(55,55,1,'Frame 1',NULL,NULL,NULL,1,'2024-11-25 06:46:13','2024-11-25 06:46:13','bda4acb6-90ba-4cb5-b2e6-76c02076e180'),(56,56,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</strong></p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55]}',1,'2024-11-25 06:46:41','2024-11-25 06:46:41','47512278-07fe-407d-a3dd-649aa4e5a44c'),(58,58,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-2','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-2','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>Lorem Ipsum</p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [54]}',1,'2024-11-25 06:47:38','2024-11-25 06:47:38','6ee57f81-d129-4ed9-ac2b-8960ea2b7c54'),(60,60,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55]}',1,'2024-11-25 06:47:45','2024-11-25 06:47:45','481fbbb3-e7fa-4c49-83ba-568735596dfc'),(62,62,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-3','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-3','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>anajbxjsbcasknxckcas</p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [54]}',1,'2024-11-25 06:48:39','2024-11-25 06:48:39','65fcb183-47d7-4372-b272-81c359f3a813'),(64,64,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-4','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-4','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>Test </p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18]}',1,'2024-11-25 06:49:12','2024-11-25 06:49:12','a497e90e-d550-41f4-ad34-a0853866dca7'),(66,66,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-4','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-4','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>Test </p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55]}',1,'2024-11-25 06:49:23','2024-11-25 06:49:23','76c64bae-014e-471e-a8e7-f62f2578a056'),(68,68,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-5','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-5','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55]}',1,'2024-11-25 06:49:57','2024-11-25 06:49:57','3aa1f2a6-b786-4cc6-a9ff-2612e825c201'),(70,70,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-6','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-6','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 06:50:34','2024-11-25 06:50:34','7a2dc9a3-97de-416a-8ce7-1c54ff8f3ad4'),(72,72,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-6','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-6','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [54], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 06:50:45','2024-11-25 06:50:45','8231d760-5605-4879-b9bc-ed827c5856b3'),(74,74,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 06:55:56','2024-11-25 06:55:56','614f89e5-6273-4039-b74b-5f2b0e3b04ed'),(76,76,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-3','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-3','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>anajbxjsbcasknxckcas</p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [54], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 06:56:01','2024-11-25 06:56:01','ee8628f6-2328-4ef2-a1a4-bca0c293ce20'),(77,77,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><h4>Where does it come from?</h4><p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \\\"de Finibus Bonorum et Malorum\\\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \\\"Lorem ipsum dolor sit amet..\\\", comes from a line in section 1.10.32.</p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 06:56:04','2024-11-25 06:56:04','41275faa-6a0a-47c0-9f24-687df59d5235'),(79,79,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-5','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-5','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"David Smith\"}',1,'2024-11-25 06:56:27','2024-11-25 06:56:27','55533b07-1238-4732-bf5c-9df9d8e727d3'),(81,81,1,'In egestas mauris non nunc volutpat efficitin ante finibus.','in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-4','news/in-egestas-mauris-non-nunc-volutpat-efficitin-ante-finibus-4','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>Test </p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"David Smith\"}',1,'2024-11-25 06:56:31','2024-11-25 06:56:31','8b6f0cf4-cc39-43a9-b968-94feaac34f4b'),(83,83,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. <br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit.c.</p><h3>Fusce efficitur congue enim non laoreet. </h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. <br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit. <br />Sed commodo mi nunc, a auctor augue fringilla at. Phasellus purus nulla, laoreet non nulla ut, lobortis euismod dolor. Suspendisse non facilisis erat, ac feugiat dui. Aliquam erat volutpat. Cras elementum tempor sollicitudin. Aliquam ut tristique libero, eu dignissim felis. Fusce consequat tortor nec feugiat lacinia. Donec eleifend sapien felis, a hendrerit lorem egestas non. Nulla ac facilisis augue. <br />Integer scelerisque dui id ligula consequat ultricies. Quisque eget ipsum sit amet massa aliquam rhoncus. Aliquam mauris neque, varius ac porta ut, eleifend ac est. Praesent iaculis a enim eget congue. Curabitur commodo odio nec ligula gravida, id blandit tellus suscipit. Integer quis enim id lectus molestie placerat at vel massa. Fusce mattis eros et ex efficitur, eu bibendum nisi efficitur. Sed bibendum a nulla a laoreet. Proin venenatis pretium eros, ut vulputate lacus tincidunt ut. Curabitur vitae ligula nunc.</p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 07:21:28','2024-11-25 07:21:28','1cc1e632-0b9e-4060-9e82-b6032a9a93f0'),(85,85,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit.c.</p><h3>Fusce efficitur congue enim non laoreet. </h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit. </p><p><br />Sed commodo mi nunc, a auctor augue fringilla at. Phasellus purus nulla, laoreet non nulla ut, lobortis euismod dolor. Suspendisse non facilisis erat, ac feugiat dui. Aliquam erat volutpat. Cras elementum tempor sollicitudin. Aliquam ut tristique libero, eu dignissim felis. Fusce consequat tortor nec feugiat lacinia. Donec eleifend sapien felis, a hendrerit lorem egestas non. Nulla ac facilisis augue. </p><p><br />Integer scelerisque dui id ligula consequat ultricies. Quisque eget ipsum sit amet massa aliquam rhoncus. Aliquam mauris neque, varius ac porta ut, eleifend ac est. Praesent iaculis a enim eget congue. Curabitur commodo odio nec ligula gravida, id blandit tellus suscipit. Integer quis enim id lectus molestie placerat at vel massa. Fusce mattis eros et ex efficitur, eu bibendum nisi efficitur. Sed bibendum a nulla a laoreet. Proin venenatis pretium eros, ut vulputate lacus tincidunt ut. Curabitur vitae ligula nunc.</p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 07:21:45','2024-11-25 07:21:45','f537108e-0290-4128-92f8-f42eca23573e'),(87,87,1,NULL,'__temp_vksgxzgudztedibtnezwtzqnzwcbiycsjpdt',NULL,NULL,1,'2024-11-25 08:06:03','2024-11-25 08:06:03','b7d7ed38-bcb1-40d2-a5dc-255c8929a638'),(88,88,1,NULL,'__temp_frtpaocdkilykvjqcstjzkyucpqenkurxygm',NULL,'{\"26485dda-4e20-482f-8fa7-f425bc00b47c\": []}',1,'2024-11-25 08:06:18','2024-11-25 08:06:18','04bccf07-fe09-4bf9-a963-7ac3b0ce74da'),(90,90,1,'Content','content',NULL,'{\"9d42365a-b6cc-4efa-9e21-75d0485f4e2e\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit.c.</p><h3>Fusce efficitur congue enim non laoreet. </h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit. </p><p><br />Sed commodo mi nunc, a auctor augue fringilla at. Phasellus purus nulla, laoreet non nulla ut, lobortis euismod dolor. Suspendisse non facilisis erat, ac feugiat dui. Aliquam erat volutpat. Cras elementum tempor sollicitudin. Aliquam ut tristique libero, eu dignissim felis. Fusce consequat tortor nec feugiat lacinia. Donec eleifend sapien felis, a hendrerit lorem egestas non. Nulla ac facilisis augue. </p><p><br />Integer scelerisque dui id ligula consequat ultricies. Quisque eget ipsum sit amet massa aliquam rhoncus. Aliquam mauris neque, varius ac porta ut, eleifend ac est. Praesent iaculis a enim eget congue. Curabitur commodo odio nec ligula gravida, id blandit tellus suscipit. Integer quis enim id lectus molestie placerat at vel massa. Fusce mattis eros et ex efficitur, eu bibendum nisi efficitur. Sed bibendum a nulla a laoreet. Proin venenatis pretium eros, ut vulputate lacus tincidunt ut. Curabitur vitae ligula nunc.</p>\", \"e135c047-9b8d-4aa0-990f-1bc9a5bf96c2\": \"lg:w-3/4\", \"e5c64962-e6a2-4fe2-89dc-08babd909c58\": \"bottom\"}',1,'2024-11-25 08:07:01','2024-11-25 10:11:10','7b5fea8b-5f6f-4316-b801-cc8b4134f48b'),(91,91,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"4aa92777-c4a7-4baa-8904-d92f9e085fb6\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit.c.</p><h3>Fusce efficitur congue enim non laoreet. </h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit. </p><p><br />Sed commodo mi nunc, a auctor augue fringilla at. Phasellus purus nulla, laoreet non nulla ut, lobortis euismod dolor. Suspendisse non facilisis erat, ac feugiat dui. Aliquam erat volutpat. Cras elementum tempor sollicitudin. Aliquam ut tristique libero, eu dignissim felis. Fusce consequat tortor nec feugiat lacinia. Donec eleifend sapien felis, a hendrerit lorem egestas non. Nulla ac facilisis augue. </p><p><br />Integer scelerisque dui id ligula consequat ultricies. Quisque eget ipsum sit amet massa aliquam rhoncus. Aliquam mauris neque, varius ac porta ut, eleifend ac est. Praesent iaculis a enim eget congue. Curabitur commodo odio nec ligula gravida, id blandit tellus suscipit. Integer quis enim id lectus molestie placerat at vel massa. Fusce mattis eros et ex efficitur, eu bibendum nisi efficitur. Sed bibendum a nulla a laoreet. Proin venenatis pretium eros, ut vulputate lacus tincidunt ut. Curabitur vitae ligula nunc.</p>\", \"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 08:07:01','2024-11-25 08:07:01','fc87acf3-3194-4447-ace2-e872f669eb41'),(92,92,1,'Content','content',NULL,'{\"9d42365a-b6cc-4efa-9e21-75d0485f4e2e\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit.c.</p>\"}',1,'2024-11-25 08:07:01','2024-11-25 08:07:01','7c4cc845-6e9a-4820-a6b4-73b742326894'),(95,95,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 08:16:04','2024-11-25 08:16:04','8b129d56-927e-46de-b415-05e89d99114a'),(96,96,1,'Content','content',NULL,'{\"9d42365a-b6cc-4efa-9e21-75d0485f4e2e\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit.c.</p><h3>Fusce efficitur congue enim non laoreet. </h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit. </p><p><br />Sed commodo mi nunc, a auctor augue fringilla at. Phasellus purus nulla, laoreet non nulla ut, lobortis euismod dolor. Suspendisse non facilisis erat, ac feugiat dui. Aliquam erat volutpat. Cras elementum tempor sollicitudin. Aliquam ut tristique libero, eu dignissim felis. Fusce consequat tortor nec feugiat lacinia. Donec eleifend sapien felis, a hendrerit lorem egestas non. Nulla ac facilisis augue. </p><p><br />Integer scelerisque dui id ligula consequat ultricies. Quisque eget ipsum sit amet massa aliquam rhoncus. Aliquam mauris neque, varius ac porta ut, eleifend ac est. Praesent iaculis a enim eget congue. Curabitur commodo odio nec ligula gravida, id blandit tellus suscipit. Integer quis enim id lectus molestie placerat at vel massa. Fusce mattis eros et ex efficitur, eu bibendum nisi efficitur. Sed bibendum a nulla a laoreet. Proin venenatis pretium eros, ut vulputate lacus tincidunt ut. Curabitur vitae ligula nunc.</p>\"}',1,'2024-11-25 08:16:04','2024-11-25 08:16:04','6111c989-cadc-48c6-bd6b-f0bdfadeff62'),(97,97,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 08:18:19','2024-11-25 08:18:19','b8a4db8a-c913-4dfc-832a-6db290a4ef6f'),(98,98,1,'Content','content',NULL,'{\"9d42365a-b6cc-4efa-9e21-75d0485f4e2e\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit.c.</p><h3>Fusce efficitur congue enim non laoreet. </h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit. </p><p><br />Sed commodo mi nunc, a auctor augue fringilla at. Phasellus purus nulla, laoreet non nulla ut, lobortis euismod dolor. Suspendisse non facilisis erat, ac feugiat dui. Aliquam erat volutpat. Cras elementum tempor sollicitudin. Aliquam ut tristique libero, eu dignissim felis. Fusce consequat tortor nec feugiat lacinia. Donec eleifend sapien felis, a hendrerit lorem egestas non. Nulla ac facilisis augue. </p><p><br />Integer scelerisque dui id ligula consequat ultricies. Quisque eget ipsum sit amet massa aliquam rhoncus. Aliquam mauris neque, varius ac porta ut, eleifend ac est. Praesent iaculis a enim eget congue. Curabitur commodo odio nec ligula gravida, id blandit tellus suscipit. Integer quis enim id lectus molestie placerat at vel massa. Fusce mattis eros et ex efficitur, eu bibendum nisi efficitur. Sed bibendum a nulla a laoreet. Proin venenatis pretium eros, ut vulputate lacus tincidunt ut. Curabitur vitae ligula nunc.</p>\", \"e5c64962-e6a2-4fe2-89dc-08babd909c58\": \"topBottom\"}',1,'2024-11-25 08:18:19','2024-11-25 08:18:19','00222420-0fb5-4689-bedb-7f7c58f7c989'),(101,101,1,'Image and Text','image-and-text',NULL,'{\"26485dda-4e20-482f-8fa7-f425bc00b47c\": [54], \"3cba98e0-5c15-4a0f-939b-18e23cdd05fb\": false, \"7af9c571-2e53-49ba-acc8-4a7d3d9e9cb2\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p><p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"82ca84f7-6361-4afc-99ce-7d1001f0544b\": \"none\", \"90d47f07-a348-4cf6-b54c-52b94b7e3b2c\": false, \"d4503cda-f661-4454-966e-39d12d4bc8cb\": \"\", \"ee4daa79-ca03-488a-b6ff-87f6f1f057c9\": \"Test\"}',1,'2024-11-25 08:28:17','2024-11-25 10:50:10','6ac5a50d-2b5d-4a25-9b82-7395f270291a'),(102,102,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 08:28:17','2024-11-25 08:28:17','352ed169-026a-4a52-9145-fa0d7118dca0'),(103,103,1,'Image and Text','image-and-text',NULL,'{\"26485dda-4e20-482f-8fa7-f425bc00b47c\": [54], \"3cba98e0-5c15-4a0f-939b-18e23cdd05fb\": false, \"7af9c571-2e53-49ba-acc8-4a7d3d9e9cb2\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p><p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"90d47f07-a348-4cf6-b54c-52b94b7e3b2c\": false}',1,'2024-11-25 08:28:17','2024-11-25 08:28:17','cae50b69-d481-4f7b-b1ab-5eefdcdd7ff6'),(105,105,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [18], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 08:29:03','2024-11-25 08:29:03','9f7b11c9-5f17-4ca0-a8b1-872d63a94426'),(106,106,1,'Image and Text','image-and-text',NULL,'{\"26485dda-4e20-482f-8fa7-f425bc00b47c\": [54], \"3cba98e0-5c15-4a0f-939b-18e23cdd05fb\": false, \"7af9c571-2e53-49ba-acc8-4a7d3d9e9cb2\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p><p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"90d47f07-a348-4cf6-b54c-52b94b7e3b2c\": false, \"ee4daa79-ca03-488a-b6ff-87f6f1f057c9\": \"Test\"}',1,'2024-11-25 08:29:03','2024-11-25 08:29:03','711c461f-a71c-4e25-85f4-5e5c9c989bf0'),(108,108,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 09:30:08','2024-11-25 09:30:08','4551cc43-af3e-4337-9b26-71d8fe0fb27b'),(109,109,1,'Image and Text','image-and-text',NULL,'{\"26485dda-4e20-482f-8fa7-f425bc00b47c\": [54], \"3cba98e0-5c15-4a0f-939b-18e23cdd05fb\": false, \"7af9c571-2e53-49ba-acc8-4a7d3d9e9cb2\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p><p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"90d47f07-a348-4cf6-b54c-52b94b7e3b2c\": false, \"ee4daa79-ca03-488a-b6ff-87f6f1f057c9\": \"Test\"}',1,'2024-11-25 09:30:08','2024-11-25 09:30:08','36993a27-868f-4963-bc67-9499fa55e546'),(111,111,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 09:41:36','2024-11-25 09:41:36','f65d3327-ce4a-44f2-94e3-def8f19edb6e'),(112,112,1,'Content','content',NULL,'{\"9d42365a-b6cc-4efa-9e21-75d0485f4e2e\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit.c.</p><h3>Fusce efficitur congue enim non laoreet. </h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit. </p><p><br />Sed commodo mi nunc, a auctor augue fringilla at. Phasellus purus nulla, laoreet non nulla ut, lobortis euismod dolor. Suspendisse non facilisis erat, ac feugiat dui. Aliquam erat volutpat. Cras elementum tempor sollicitudin. Aliquam ut tristique libero, eu dignissim felis. Fusce consequat tortor nec feugiat lacinia. Donec eleifend sapien felis, a hendrerit lorem egestas non. Nulla ac facilisis augue. </p><p><br />Integer scelerisque dui id ligula consequat ultricies. Quisque eget ipsum sit amet massa aliquam rhoncus. Aliquam mauris neque, varius ac porta ut, eleifend ac est. Praesent iaculis a enim eget congue. Curabitur commodo odio nec ligula gravida, id blandit tellus suscipit. Integer quis enim id lectus molestie placerat at vel massa. Fusce mattis eros et ex efficitur, eu bibendum nisi efficitur. Sed bibendum a nulla a laoreet. Proin venenatis pretium eros, ut vulputate lacus tincidunt ut. Curabitur vitae ligula nunc.</p>\", \"e135c047-9b8d-4aa0-990f-1bc9a5bf96c2\": \"lg:w-3/4\", \"e5c64962-e6a2-4fe2-89dc-08babd909c58\": \"topBottom\"}',1,'2024-11-25 09:41:36','2024-11-25 09:41:36','d5c1bac5-43c7-4c84-a875-4b7d4af3ac3d'),(114,114,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 09:47:28','2024-11-25 09:47:28','6caef9f1-9e56-4bc3-b623-c8b0c2a5a88b'),(115,115,1,'Content','content',NULL,'{\"9d42365a-b6cc-4efa-9e21-75d0485f4e2e\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit.c.</p><h3>Fusce efficitur congue enim non laoreet. </h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit. </p><p><br />Sed commodo mi nunc, a auctor augue fringilla at. Phasellus purus nulla, laoreet non nulla ut, lobortis euismod dolor. Suspendisse non facilisis erat, ac feugiat dui. Aliquam erat volutpat. Cras elementum tempor sollicitudin. Aliquam ut tristique libero, eu dignissim felis. Fusce consequat tortor nec feugiat lacinia. Donec eleifend sapien felis, a hendrerit lorem egestas non. Nulla ac facilisis augue. </p><p><br />Integer scelerisque dui id ligula consequat ultricies. Quisque eget ipsum sit amet massa aliquam rhoncus. Aliquam mauris neque, varius ac porta ut, eleifend ac est. Praesent iaculis a enim eget congue. Curabitur commodo odio nec ligula gravida, id blandit tellus suscipit. Integer quis enim id lectus molestie placerat at vel massa. Fusce mattis eros et ex efficitur, eu bibendum nisi efficitur. Sed bibendum a nulla a laoreet. Proin venenatis pretium eros, ut vulputate lacus tincidunt ut. Curabitur vitae ligula nunc.</p>\", \"e135c047-9b8d-4aa0-990f-1bc9a5bf96c2\": \"lg:w-3/4\", \"e5c64962-e6a2-4fe2-89dc-08babd909c58\": \"topBottom\"}',1,'2024-11-25 09:47:28','2024-11-25 09:47:28','14823eea-6024-4472-9ffc-0ffe6aac7f91'),(116,116,1,'Image and Text','image-and-text',NULL,'{\"26485dda-4e20-482f-8fa7-f425bc00b47c\": [54], \"3cba98e0-5c15-4a0f-939b-18e23cdd05fb\": false, \"7af9c571-2e53-49ba-acc8-4a7d3d9e9cb2\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p><p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"90d47f07-a348-4cf6-b54c-52b94b7e3b2c\": false, \"d4503cda-f661-4454-966e-39d12d4bc8cb\": \"\", \"ee4daa79-ca03-488a-b6ff-87f6f1f057c9\": \"Test\"}',1,'2024-11-25 09:47:28','2024-11-25 09:47:28','184dd8cd-42e1-4106-9706-8c9049543d0f'),(118,118,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 09:47:54','2024-11-25 09:47:54','f891268c-4481-4eab-be7d-d65b47b06cda'),(119,119,1,'Content','content',NULL,'{\"9d42365a-b6cc-4efa-9e21-75d0485f4e2e\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit.c.</p><h3>Fusce efficitur congue enim non laoreet. </h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit. </p><p><br />Sed commodo mi nunc, a auctor augue fringilla at. Phasellus purus nulla, laoreet non nulla ut, lobortis euismod dolor. Suspendisse non facilisis erat, ac feugiat dui. Aliquam erat volutpat. Cras elementum tempor sollicitudin. Aliquam ut tristique libero, eu dignissim felis. Fusce consequat tortor nec feugiat lacinia. Donec eleifend sapien felis, a hendrerit lorem egestas non. Nulla ac facilisis augue. </p><p><br />Integer scelerisque dui id ligula consequat ultricies. Quisque eget ipsum sit amet massa aliquam rhoncus. Aliquam mauris neque, varius ac porta ut, eleifend ac est. Praesent iaculis a enim eget congue. Curabitur commodo odio nec ligula gravida, id blandit tellus suscipit. Integer quis enim id lectus molestie placerat at vel massa. Fusce mattis eros et ex efficitur, eu bibendum nisi efficitur. Sed bibendum a nulla a laoreet. Proin venenatis pretium eros, ut vulputate lacus tincidunt ut. Curabitur vitae ligula nunc.</p>\", \"e135c047-9b8d-4aa0-990f-1bc9a5bf96c2\": \"lg:w-3/4\", \"e5c64962-e6a2-4fe2-89dc-08babd909c58\": \"none\"}',1,'2024-11-25 09:47:54','2024-11-25 09:47:54','dd85feab-71d1-4518-a2c3-e8c91505ed3f'),(120,120,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 09:48:35','2024-11-25 09:48:35','d3c6a339-a9fc-4615-b606-e7f92a617ba8'),(123,123,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 10:10:34','2024-11-25 10:10:34','1bc64359-e340-4876-bece-4516cce7b743'),(124,124,1,'Image and Text','image-and-text',NULL,'{\"26485dda-4e20-482f-8fa7-f425bc00b47c\": [54], \"3cba98e0-5c15-4a0f-939b-18e23cdd05fb\": true, \"7af9c571-2e53-49ba-acc8-4a7d3d9e9cb2\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p><p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"82ca84f7-6361-4afc-99ce-7d1001f0544b\": \"none\", \"90d47f07-a348-4cf6-b54c-52b94b7e3b2c\": false, \"d4503cda-f661-4454-966e-39d12d4bc8cb\": \"\", \"ee4daa79-ca03-488a-b6ff-87f6f1f057c9\": \"Test\"}',1,'2024-11-25 10:10:34','2024-11-25 10:10:34','c4a52ad4-8db1-458b-b714-cdb0be004eb6'),(126,126,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 10:11:12','2024-11-25 10:11:12','622a7c71-f6d2-459e-b74b-e27c21040c3d'),(127,127,1,'Content','content',NULL,'{\"9d42365a-b6cc-4efa-9e21-75d0485f4e2e\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit.c.</p><h3>Fusce efficitur congue enim non laoreet. </h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit. </p><p><br />Sed commodo mi nunc, a auctor augue fringilla at. Phasellus purus nulla, laoreet non nulla ut, lobortis euismod dolor. Suspendisse non facilisis erat, ac feugiat dui. Aliquam erat volutpat. Cras elementum tempor sollicitudin. Aliquam ut tristique libero, eu dignissim felis. Fusce consequat tortor nec feugiat lacinia. Donec eleifend sapien felis, a hendrerit lorem egestas non. Nulla ac facilisis augue. </p><p><br />Integer scelerisque dui id ligula consequat ultricies. Quisque eget ipsum sit amet massa aliquam rhoncus. Aliquam mauris neque, varius ac porta ut, eleifend ac est. Praesent iaculis a enim eget congue. Curabitur commodo odio nec ligula gravida, id blandit tellus suscipit. Integer quis enim id lectus molestie placerat at vel massa. Fusce mattis eros et ex efficitur, eu bibendum nisi efficitur. Sed bibendum a nulla a laoreet. Proin venenatis pretium eros, ut vulputate lacus tincidunt ut. Curabitur vitae ligula nunc.</p>\", \"e135c047-9b8d-4aa0-990f-1bc9a5bf96c2\": \"lg:w-3/4\", \"e5c64962-e6a2-4fe2-89dc-08babd909c58\": \"bottom\"}',1,'2024-11-25 10:11:12','2024-11-25 10:11:12','ecda7adb-8fab-481b-81b1-9f6992ce1e85'),(129,129,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [55], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"John Smith\"}',1,'2024-11-25 10:11:29','2024-11-25 10:11:29','79b91e09-a494-47fe-b784-3f3d582151f3'),(132,132,1,'Homepage','homepage','homepage',NULL,1,'2024-11-25 10:59:54','2024-11-25 10:59:54','d8ce1ac5-f7fa-4ddc-86f7-0daf2db04bec'),(133,133,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at-2','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at-2','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [54], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"David Smith\"}',1,'2024-11-25 11:10:15','2024-11-25 11:10:58','29af72cc-0835-4cc4-807d-a10b44f7c492'),(134,134,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at-2','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at-2','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [54], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"David Smith\"}',1,'2024-11-25 11:11:02','2024-11-25 11:11:02','c4e794ab-6a89-4a99-9d83-1d60adb4a8d3'),(137,137,1,'Text','text',NULL,'{\"9d42365a-b6cc-4efa-9e21-75d0485f4e2e\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><h3>Fusce efficitur congue enim non laoreet.</h3><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit.c.</p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. <br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit. <br />Sed commodo mi nunc, a auctor augue fringilla at. Phasellus purus nulla, laoreet non nulla ut, lobortis euismod dolor. Suspendisse non facilisis erat, ac feugiat dui. Aliquam erat volutpat. Cras elementum tempor sollicitudin. Aliquam ut tristique libero, eu dignissim felis. Fusce consequat tortor nec feugiat lacinia. Donec eleifend sapien felis, a hendrerit lorem egestas non. Nulla ac facilisis augue. <br />Integer scelerisque dui id ligula consequat ultricies. Quisque eget ipsum sit amet massa aliquam rhoncus. Aliquam mauris neque, varius ac porta ut, eleifend ac est. Praesent iaculis a enim eget congue. Curabitur commodo odio nec ligula gravida, id blandit tellus suscipit. Integer quis enim id lectus molestie placerat at vel massa. Fusce mattis eros et ex efficitur, eu bibendum nisi efficitur. Sed bibendum a nulla a laoreet. Proin venenatis pretium eros, ut vulputate lacus tincidunt ut. Curabitur vitae ligula nunc.</p>\", \"e135c047-9b8d-4aa0-990f-1bc9a5bf96c2\": \"lg:w-3/4\", \"e5c64962-e6a2-4fe2-89dc-08babd909c58\": \"topBottom\"}',1,'2024-11-25 11:13:07','2024-11-25 13:07:48','65808f9c-8ab7-4f28-8660-7544fd1bdd25'),(138,138,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at-2','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at-2','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [54], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"David Smith\"}',1,'2024-11-25 11:13:07','2024-11-25 11:13:07','026813fd-7d4e-4802-86a7-a773b0c8c7c3'),(139,139,1,'Text','text',NULL,'{\"9d42365a-b6cc-4efa-9e21-75d0485f4e2e\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><h3>Fusce efficitur congue enim non laoreet.</h3><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit.c.</p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. <br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit. <br />Sed commodo mi nunc, a auctor augue fringilla at. Phasellus purus nulla, laoreet non nulla ut, lobortis euismod dolor. Suspendisse non facilisis erat, ac feugiat dui. Aliquam erat volutpat. Cras elementum tempor sollicitudin. Aliquam ut tristique libero, eu dignissim felis. Fusce consequat tortor nec feugiat lacinia. Donec eleifend sapien felis, a hendrerit lorem egestas non. Nulla ac facilisis augue. <br />Integer scelerisque dui id ligula consequat ultricies. Quisque eget ipsum sit amet massa aliquam rhoncus. Aliquam mauris neque, varius ac porta ut, eleifend ac est. Praesent iaculis a enim eget congue. Curabitur commodo odio nec ligula gravida, id blandit tellus suscipit. Integer quis enim id lectus molestie placerat at vel massa. Fusce mattis eros et ex efficitur, eu bibendum nisi efficitur. Sed bibendum a nulla a laoreet. Proin venenatis pretium eros, ut vulputate lacus tincidunt ut. Curabitur vitae ligula nunc.</p>\", \"e135c047-9b8d-4aa0-990f-1bc9a5bf96c2\": \"w-full\", \"e5c64962-e6a2-4fe2-89dc-08babd909c58\": \"topBottom\"}',1,'2024-11-25 11:13:07','2024-11-25 11:13:07','7cec1397-3de1-446a-8ac5-41fae2d23670'),(141,141,1,'Sed commodo mi nunc, a auctor augue fringilla at.','sed-commodo-mi-nunc-a-auctor-augue-fringilla-at-2','news/sed-commodo-mi-nunc-a-auctor-augue-fringilla-at-2','{\"735b9e7b-1762-4b48-89f1-5416895bd6d3\": \"<p>Pellentesque eu tortor nec diam tristique interdum ut in orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>\", \"8543a8ed-d05a-4df4-90d0-df04c2b06519\": [54], \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\": \"David Smith\"}',1,'2024-11-25 13:07:49','2024-11-25 13:07:49','5840d4aa-33b8-4dd6-8bf1-92fdb16709ee'),(142,142,1,'Text','text',NULL,'{\"9d42365a-b6cc-4efa-9e21-75d0485f4e2e\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. </p><h3>Fusce efficitur congue enim non laoreet.</h3><p><br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit.c.</p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut purus enim. Morbi venenatis justo sed elit fringilla blandit. Integer aliquam sed augue sit amet sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Fusce efficitur congue enim non laoreet. Donec eleifend, mauris ac semper sodales, lectus erat rhoncus orci, eleifend euismod leo neque nec dui. Quisque nec neque sit amet velit sagittis suscipit. <br />Duis nec tincidunt lectus, vel semper massa. Praesent sollicitudin felis sit amet laoreet sodales. Aliquam efficitur maximus sagittis. In pellentesque tellus a nunc molestie, vel suscipit nunc gravida. Pellentesque tempus magna nec est vehicula tincidunt. Quisque eget placerat leo, sit amet consequat mi. Nullam velit mauris, porta quis mauris ac, porttitor rutrum justo. Etiam consectetur vel risus nec commodo. Curabitur odio eros, maximus sed faucibus ut, vulputate id est. Fusce fringilla diam est, ut laoreet nulla aliquam non. Ut tincidunt mollis sollicitudin. Ut a sapien quis felis dictum suscipit. <br />Sed commodo mi nunc, a auctor augue fringilla at. Phasellus purus nulla, laoreet non nulla ut, lobortis euismod dolor. Suspendisse non facilisis erat, ac feugiat dui. Aliquam erat volutpat. Cras elementum tempor sollicitudin. Aliquam ut tristique libero, eu dignissim felis. Fusce consequat tortor nec feugiat lacinia. Donec eleifend sapien felis, a hendrerit lorem egestas non. Nulla ac facilisis augue. <br />Integer scelerisque dui id ligula consequat ultricies. Quisque eget ipsum sit amet massa aliquam rhoncus. Aliquam mauris neque, varius ac porta ut, eleifend ac est. Praesent iaculis a enim eget congue. Curabitur commodo odio nec ligula gravida, id blandit tellus suscipit. Integer quis enim id lectus molestie placerat at vel massa. Fusce mattis eros et ex efficitur, eu bibendum nisi efficitur. Sed bibendum a nulla a laoreet. Proin venenatis pretium eros, ut vulputate lacus tincidunt ut. Curabitur vitae ligula nunc.</p>\", \"e135c047-9b8d-4aa0-990f-1bc9a5bf96c2\": \"lg:w-3/4\", \"e5c64962-e6a2-4fe2-89dc-08babd909c58\": \"topBottom\"}',1,'2024-11-25 13:07:49','2024-11-25 13:07:49','9e5c4a6a-2d53-492c-a047-6eb2de639866');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (2,1,NULL,NULL,NULL,1,'2024-11-24 20:10:49',NULL,0,0,'2024-11-24 20:10:49','2024-11-24 20:10:49'),(3,1,NULL,NULL,NULL,1,'2024-11-24 20:46:07',NULL,0,0,'2024-11-24 20:46:07','2024-11-24 20:46:07'),(4,2,NULL,NULL,NULL,2,'2024-11-24 21:00:00',NULL,NULL,NULL,'2024-11-24 21:00:08','2024-11-24 21:00:08'),(5,2,NULL,NULL,NULL,2,'2024-11-24 21:00:00',NULL,NULL,NULL,'2024-11-24 21:00:08','2024-11-24 21:00:08'),(6,1,NULL,NULL,NULL,1,'2024-11-24 21:31:00',NULL,NULL,NULL,'2024-11-24 21:31:07','2024-11-24 21:31:16'),(7,1,NULL,NULL,NULL,1,'2024-11-24 21:31:00',NULL,NULL,NULL,'2024-11-24 21:31:16','2024-11-24 21:31:16'),(11,1,NULL,NULL,NULL,1,'2024-11-24 21:31:00',NULL,NULL,NULL,'2024-11-25 00:02:33','2024-11-25 00:02:33'),(15,1,NULL,NULL,NULL,1,'2024-11-24 21:31:00',NULL,NULL,NULL,'2024-11-25 00:11:18','2024-11-25 00:11:18'),(19,1,NULL,NULL,NULL,1,'2024-11-24 21:31:00',NULL,NULL,NULL,'2024-11-25 00:31:23','2024-11-25 00:31:23'),(20,1,NULL,NULL,NULL,1,'2024-11-25 01:21:00',NULL,NULL,NULL,'2024-11-25 01:20:43','2024-11-25 01:21:01'),(21,1,NULL,NULL,NULL,1,'2024-11-25 01:21:00',NULL,NULL,NULL,'2024-11-25 01:21:01','2024-11-25 01:21:01'),(23,1,NULL,NULL,NULL,1,'2024-11-24 21:31:00',NULL,NULL,NULL,'2024-11-25 01:37:33','2024-11-25 01:37:33'),(25,1,NULL,NULL,NULL,1,'2024-11-24 21:31:00',NULL,NULL,NULL,'2024-11-25 02:52:48','2024-11-25 02:52:48'),(26,1,NULL,NULL,NULL,1,'2024-11-25 02:53:00',NULL,NULL,NULL,'2024-11-25 02:52:51','2024-11-25 02:53:10'),(27,1,NULL,NULL,NULL,1,'2024-11-25 02:53:00',NULL,NULL,NULL,'2024-11-25 02:53:10','2024-11-25 02:53:10'),(29,1,NULL,NULL,NULL,1,'2024-11-24 21:31:00',NULL,NULL,NULL,'2024-11-25 03:20:53','2024-11-25 03:20:53'),(30,1,NULL,NULL,NULL,1,'2024-11-25 01:21:00',NULL,NULL,NULL,'2024-11-25 03:20:59','2024-11-25 03:20:59'),(32,1,NULL,NULL,NULL,1,'2024-11-25 02:53:00',NULL,NULL,NULL,'2024-11-25 03:21:04','2024-11-25 03:21:04'),(33,1,NULL,NULL,NULL,1,'2024-11-25 03:44:00',NULL,NULL,NULL,'2024-11-25 03:44:27','2024-11-25 03:44:52'),(34,1,NULL,NULL,NULL,1,'2024-11-25 03:44:00',NULL,NULL,NULL,'2024-11-25 03:44:52','2024-11-25 03:44:52'),(35,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 03:44:54','2024-11-25 03:45:09'),(36,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 03:45:09','2024-11-25 03:45:09'),(37,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 03:45:09','2024-11-25 03:45:19'),(38,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 03:45:19','2024-11-25 03:45:19'),(39,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 03:45:21','2024-11-25 03:45:21'),(40,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 03:45:21','2024-11-25 03:45:34'),(41,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 03:45:34','2024-11-25 03:45:34'),(43,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 04:21:34','2024-11-25 04:21:34'),(45,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 04:25:27','2024-11-25 04:25:27'),(47,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 04:46:02','2024-11-25 04:46:02'),(49,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 06:30:17','2024-11-25 06:30:17'),(50,1,NULL,NULL,NULL,1,'2024-11-24 21:31:00',NULL,NULL,NULL,'2024-11-25 06:35:03','2024-11-25 06:35:03'),(52,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 06:44:01','2024-11-25 06:44:01'),(56,1,NULL,NULL,NULL,1,'2024-11-24 21:31:00',NULL,NULL,NULL,'2024-11-25 06:46:41','2024-11-25 06:46:41'),(58,1,NULL,NULL,NULL,1,'2024-11-25 01:21:00',NULL,NULL,NULL,'2024-11-25 06:47:38','2024-11-25 06:47:38'),(60,1,NULL,NULL,NULL,1,'2024-11-24 21:31:00',NULL,NULL,NULL,'2024-11-25 06:47:45','2024-11-25 06:47:45'),(62,1,NULL,NULL,NULL,1,'2024-11-25 02:53:00',NULL,NULL,NULL,'2024-11-25 06:48:39','2024-11-25 06:48:39'),(64,1,NULL,NULL,NULL,1,'2024-11-25 03:44:00',NULL,NULL,NULL,'2024-11-25 06:49:12','2024-11-25 06:49:12'),(66,1,NULL,NULL,NULL,1,'2024-11-25 03:44:00',NULL,NULL,NULL,'2024-11-25 06:49:23','2024-11-25 06:49:23'),(68,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 06:49:57','2024-11-25 06:49:57'),(70,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 06:50:34','2024-11-25 06:50:34'),(72,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 06:50:45','2024-11-25 06:50:45'),(74,1,NULL,NULL,NULL,1,'2024-11-24 21:31:00',NULL,NULL,NULL,'2024-11-25 06:55:56','2024-11-25 06:55:56'),(76,1,NULL,NULL,NULL,1,'2024-11-25 02:53:00',NULL,NULL,NULL,'2024-11-25 06:56:01','2024-11-25 06:56:01'),(77,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 06:56:04','2024-11-25 06:56:04'),(79,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 06:56:27','2024-11-25 06:56:27'),(81,1,NULL,NULL,NULL,1,'2024-11-25 03:44:00',NULL,NULL,NULL,'2024-11-25 06:56:31','2024-11-25 06:56:31'),(83,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 07:21:28','2024-11-25 07:21:28'),(85,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 07:21:45','2024-11-25 07:21:45'),(90,NULL,NULL,40,8,5,'2024-11-25 08:06:00',NULL,NULL,NULL,'2024-11-25 08:07:01','2024-11-25 08:07:01'),(91,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 08:07:01','2024-11-25 08:07:01'),(92,NULL,NULL,91,8,5,'2024-11-25 08:06:00',NULL,NULL,NULL,'2024-11-25 08:07:01','2024-11-25 08:07:01'),(95,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 08:16:04','2024-11-25 08:16:04'),(96,NULL,NULL,95,8,5,'2024-11-25 08:06:00',NULL,NULL,NULL,'2024-11-25 08:16:04','2024-11-25 08:16:04'),(97,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 08:18:19','2024-11-25 08:18:19'),(98,NULL,NULL,97,8,5,'2024-11-25 08:06:00',NULL,NULL,NULL,'2024-11-25 08:18:19','2024-11-25 08:18:19'),(101,NULL,NULL,40,8,4,'2024-11-25 08:25:00',NULL,NULL,NULL,'2024-11-25 08:28:17','2024-11-25 08:28:17'),(102,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 08:28:17','2024-11-25 08:28:17'),(103,NULL,NULL,102,8,4,'2024-11-25 08:25:00',NULL,NULL,NULL,'2024-11-25 08:28:17','2024-11-25 08:28:17'),(105,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 08:29:03','2024-11-25 08:29:03'),(106,NULL,NULL,105,8,4,'2024-11-25 08:25:00',NULL,NULL,NULL,'2024-11-25 08:29:03','2024-11-25 08:29:03'),(108,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 09:30:08','2024-11-25 09:30:08'),(109,NULL,NULL,108,8,4,'2024-11-25 08:25:00',NULL,NULL,NULL,'2024-11-25 09:30:08','2024-11-25 09:30:08'),(111,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 09:41:36','2024-11-25 09:41:36'),(112,NULL,NULL,111,8,5,'2024-11-25 08:06:00',NULL,NULL,NULL,'2024-11-25 09:41:36','2024-11-25 09:41:36'),(114,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 09:47:28','2024-11-25 09:47:28'),(115,NULL,NULL,114,8,5,'2024-11-25 08:06:00',NULL,NULL,NULL,'2024-11-25 09:47:28','2024-11-25 09:47:28'),(116,NULL,NULL,114,8,4,'2024-11-25 08:25:00',NULL,NULL,NULL,'2024-11-25 09:47:28','2024-11-25 09:47:28'),(118,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 09:47:54','2024-11-25 09:47:54'),(119,NULL,NULL,118,8,5,'2024-11-25 08:06:00',NULL,NULL,NULL,'2024-11-25 09:47:54','2024-11-25 09:47:54'),(120,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 09:48:35','2024-11-25 09:48:35'),(123,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 10:10:34','2024-11-25 10:10:34'),(124,NULL,NULL,123,8,4,'2024-11-25 08:25:00',NULL,NULL,NULL,'2024-11-25 10:10:34','2024-11-25 10:10:34'),(126,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 10:11:12','2024-11-25 10:11:12'),(127,NULL,NULL,126,8,5,'2024-11-25 08:06:00',NULL,NULL,NULL,'2024-11-25 10:11:12','2024-11-25 10:11:12'),(129,1,NULL,NULL,NULL,1,'2024-11-25 03:45:00',NULL,NULL,NULL,'2024-11-25 10:11:29','2024-11-25 10:11:29'),(132,2,NULL,NULL,NULL,2,'2024-11-24 21:00:00',NULL,NULL,NULL,'2024-11-25 10:59:54','2024-11-25 10:59:54'),(133,1,NULL,NULL,NULL,1,'2024-11-25 11:11:00',NULL,NULL,NULL,'2024-11-25 11:10:15','2024-11-25 11:11:02'),(134,1,NULL,NULL,NULL,1,'2024-11-25 11:11:00',NULL,NULL,NULL,'2024-11-25 11:11:02','2024-11-25 11:11:02'),(137,NULL,NULL,133,8,5,'2024-11-25 11:13:00',NULL,NULL,NULL,'2024-11-25 11:13:07','2024-11-25 11:13:07'),(138,1,NULL,NULL,NULL,1,'2024-11-25 11:11:00',NULL,NULL,NULL,'2024-11-25 11:13:07','2024-11-25 11:13:07'),(139,NULL,NULL,138,8,5,'2024-11-25 11:13:00',NULL,NULL,NULL,'2024-11-25 11:13:07','2024-11-25 11:13:07'),(141,1,NULL,NULL,NULL,1,'2024-11-25 11:11:00',NULL,NULL,NULL,'2024-11-25 13:07:49','2024-11-25 13:07:49'),(142,NULL,NULL,141,8,5,'2024-11-25 11:13:00',NULL,NULL,NULL,'2024-11-25 13:07:49','2024-11-25 13:07:49');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries_authors` VALUES (2,1,1),(3,1,1),(6,1,1),(7,1,1),(11,1,1),(15,1,1),(19,1,1),(20,1,1),(21,1,1),(23,1,1),(25,1,1),(26,1,1),(27,1,1),(29,1,1),(30,1,1),(32,1,1),(33,1,1),(34,1,1),(35,1,1),(36,1,1),(37,1,1),(38,1,1),(39,1,1),(40,1,1),(41,1,1),(43,1,1),(45,1,1),(47,1,1),(49,1,1),(50,1,1),(52,1,1),(56,1,1),(58,1,1),(60,1,1),(62,1,1),(64,1,1),(66,1,1),(68,1,1),(70,1,1),(72,1,1),(74,1,1),(76,1,1),(77,1,1),(79,1,1),(81,1,1),(83,1,1),(85,1,1),(91,1,1),(95,1,1),(97,1,1),(102,1,1),(105,1,1),(108,1,1),(111,1,1),(114,1,1),(118,1,1),(120,1,1),(123,1,1),(126,1,1),(129,1,1),(133,1,1),(134,1,1),(138,1,1),(141,1,1);
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,1,'News','news','newspaper','green',1,'site',NULL,'',1,'site',NULL,1,'2024-11-24 20:08:05','2024-11-25 06:31:46',NULL,'f0df6858-5d8c-4812-bf89-b17c116385b5'),(2,2,'Homepage','homepage','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-11-24 21:00:06','2024-11-24 21:00:06',NULL,'fcaabefb-5d4e-44ae-a74b-f34412522982'),(3,6,'Content Builder','contentBuilder','face-relieved','sky',1,'site',NULL,'',1,'site',NULL,1,'2024-11-25 07:55:53','2024-11-25 07:55:53','2024-11-25 07:59:06','3a2ec60d-e356-4c4b-84a6-932a5004f7db'),(4,7,'Image and Text','imageAndText','image-landscape','orange',1,'site',NULL,'',1,'site',NULL,1,'2024-11-25 07:59:52','2024-11-25 07:59:52',NULL,'7356786d-81fd-47ec-9ab1-6fabc41ad7e1'),(5,8,'Rich Text','richText','text','blue',1,'site',NULL,'',1,'site',NULL,1,'2024-11-25 08:05:01','2024-11-25 08:05:01',NULL,'2c379949-8c14-4875-b5f0-162c720cb22d');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"4b91be54-f1fc-4f1f-813b-45e5f5565205\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"d0f8b4b9-9a1a-416e-863f-ffcd38010984\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": \"2024-11-24T20:06:51+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"8543a8ed-d05a-4df4-90d0-df04c2b06519\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"419eeb43-dd1b-4802-8e8a-db25a812d596\", \"required\": false, \"dateAdded\": \"2024-11-24T23:58:49+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"9dae6c46-66cf-472c-b670-d6da3fe8e56f\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"58d0e1b7-5af0-4f28-bca5-6edc9448142f\", \"required\": false, \"dateAdded\": \"2024-11-25T04:21:19+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"735b9e7b-1762-4b48-89f1-5416895bd6d3\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"10f39112-111f-4c02-b6fa-bb1ea54ce2b1\", \"required\": false, \"dateAdded\": \"2024-11-25T03:20:12+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"uid\": \"6caae44c-272d-4768-85f7-4f5fbd905987\", \"type\": \"craft\\\\fieldlayoutelements\\\\HorizontalRule\", \"dateAdded\": \"2024-11-25T07:57:16+00:00\", \"userCondition\": null, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"bf470c7f-7dc5-4e40-a119-ff14f27a0d73\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"62347ed5-f9bc-4354-baa2-bb8670d74f11\", \"required\": false, \"dateAdded\": \"2024-11-25T08:05:52+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2024-11-24 20:08:05','2024-11-25 08:16:26',NULL,'c3eefcf3-0257-45b3-bea9-b8be77bb73f3'),(2,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"5bc78c10-aebb-4449-8d83-58b05d645253\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"da20dd65-7a00-4847-a8e3-a9aed580db55\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": \"2024-11-24T20:59:01+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2024-11-24 21:00:06','2024-11-24 21:00:06',NULL,'5dd5e2dd-0db5-469d-8db9-a182290f88d6'),(3,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"01c4ae5b-b8d5-4af4-9cb8-f847a01365cf\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"3ed7b224-be18-4eb6-ba6a-176ea0f8ed4c\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-11-24T23:53:58+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"2c5a0ecb-9865-4f2c-b5a3-c114729391db\", \"cols\": null, \"name\": null, \"rows\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": false, \"attribute\": \"alt\", \"dateAdded\": \"2024-11-24T23:55:23+00:00\", \"requirable\": true, \"orientation\": null, \"placeholder\": null, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2024-11-24 23:57:38','2024-11-24 23:57:38','2024-11-25 00:22:55','52cd00f6-21a0-40fb-9b0e-0eee01d58880'),(4,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"14bb8c37-3a51-48bc-a8e8-1512929ee687\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"ec0cbc02-7b53-4318-9214-fa84d1e25efb\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-11-25T00:27:42+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2024-11-25 00:30:36','2024-11-25 00:30:36',NULL,'786f8719-4a80-4352-aa13-34232be85c35'),(5,'craft\\elements\\Category','{\"tabs\": [{\"uid\": \"54210258-00be-4d54-bf6e-ec7d2ad50070\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"e7b9718d-06ed-4fd6-9b2b-e83cd6c13d99\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\TitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-11-25T06:05:01+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2024-11-25 06:06:12','2024-11-25 06:06:12',NULL,'748548f5-00b4-4987-be07-2b2598644de1'),(6,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"bf1020f3-2d14-4791-a090-237813e715ad\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"c6dba027-5a5a-41c4-a522-3cd45a415745\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": \"2024-11-25T07:54:14+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"c88020ec-f4a1-41e8-a56c-40762016bacd\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"c06c82b2-36e3-48ec-bc99-31712ff69bbc\", \"required\": false, \"dateAdded\": \"2024-11-25T07:55:53+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2024-11-25 07:55:53','2024-11-25 07:55:53','2024-11-25 07:59:06','785a2ddc-b107-4401-a8f5-e98d74df1bfb'),(7,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"f59ce6cd-039a-4b1e-a119-89263fa0bc20\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"5218cad8-a88c-4921-9247-2299cef4ef83\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": false, \"dateAdded\": \"2024-11-25T07:58:12+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"26485dda-4e20-482f-8fa7-f425bc00b47c\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"c06c82b2-36e3-48ec-bc99-31712ff69bbc\", \"required\": false, \"dateAdded\": \"2024-11-25T07:59:52+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"ee4daa79-ca03-488a-b6ff-87f6f1f057c9\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"588fd587-e28b-4dae-b639-4a550563c8f5\", \"required\": false, \"dateAdded\": \"2024-11-25T08:28:48+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"7af9c571-2e53-49ba-acc8-4a7d3d9e9cb2\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"122ccab7-faba-4bd6-ade6-d9f5a4cc307b\", \"required\": false, \"dateAdded\": \"2024-11-25T07:59:52+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"5a1bcacf-7547-4396-a5c5-a968d726a08e\", \"name\": \"Settings\", \"elements\": [{\"tip\": null, \"uid\": \"d4503cda-f661-4454-966e-39d12d4bc8cb\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 50, \"handle\": null, \"warning\": null, \"fieldUid\": \"26bc567d-aa4e-4ba3-ae96-66859e54c1fa\", \"required\": false, \"dateAdded\": \"2024-11-25T09:34:44+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"3cba98e0-5c15-4a0f-939b-18e23cdd05fb\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 50, \"handle\": null, \"warning\": null, \"fieldUid\": \"f55f1621-c4b6-4e40-8696-f50eb42e5a13\", \"required\": false, \"dateAdded\": \"2024-11-25T08:25:12+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"90d47f07-a348-4cf6-b54c-52b94b7e3b2c\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 50, \"handle\": null, \"warning\": null, \"fieldUid\": \"80514974-1421-4e34-957e-49ae988dd7e5\", \"required\": false, \"dateAdded\": \"2024-11-25T08:25:12+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"82ca84f7-6361-4afc-99ce-7d1001f0544b\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 50, \"handle\": null, \"warning\": null, \"fieldUid\": \"e4262ebf-16b4-48e0-b742-08389f3b4024\", \"required\": false, \"dateAdded\": \"2024-11-25T09:48:23+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2024-11-25 07:59:52','2024-11-25 09:48:23',NULL,'eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa'),(8,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"f3b77598-e466-4aea-8141-ac5ccb36f268\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"84bdbcf1-c225-4a09-89e9-14a346676e72\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": \"2024-11-25T08:00:01+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"9d42365a-b6cc-4efa-9e21-75d0485f4e2e\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"122ccab7-faba-4bd6-ade6-d9f5a4cc307b\", \"required\": false, \"dateAdded\": \"2024-11-25T08:05:01+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"e135c047-9b8d-4aa0-990f-1bc9a5bf96c2\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"eba9d875-d930-4e6a-aa58-de4497f6fb96\", \"required\": false, \"dateAdded\": \"2024-11-25T09:41:20+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"e5c64962-e6a2-4fe2-89dc-08babd909c58\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"e4262ebf-16b4-48e0-b742-08389f3b4024\", \"required\": false, \"dateAdded\": \"2024-11-25T08:17:48+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2024-11-25 08:05:01','2024-11-25 09:41:20',NULL,'6104a56a-762e-4da1-9546-1e40b60bdc3a');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES (1,'Text','text','global',NULL,NULL,0,'none',NULL,'craft\\ckeditor\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"ckeConfig\":\"228c56d6-4c4b-4de4-aa7b-385591661cda\",\"createButtonLabel\":null,\"defaultTransform\":null,\"enableSourceEditingForNonAdmins\":false,\"purifierConfig\":null,\"purifyHtml\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"showWordCount\":false,\"wordLimit\":null}','2024-11-24 21:30:51','2024-11-25 08:21:45',NULL,'122ccab7-faba-4bd6-ade6-d9f5a4cc307b'),(2,'Main Image','mainImage','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:71aefd52-fe8e-4c03-911c-8e5a2d7af4d5\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:71aefd52-fe8e-4c03-911c-8e5a2d7af4d5\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-11-24 23:58:12','2024-11-25 00:30:53',NULL,'419eeb43-dd1b-4802-8e8a-db25a812d596'),(3,'Description','description','global',NULL,NULL,0,'none',NULL,'craft\\ckeditor\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"*\",\"ckeConfig\":\"263944d1-259b-4205-81b1-beac9e603be1\",\"createButtonLabel\":null,\"defaultTransform\":null,\"enableSourceEditingForNonAdmins\":false,\"purifierConfig\":null,\"purifyHtml\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"showWordCount\":false,\"wordLimit\":null}','2024-11-25 03:19:52','2024-11-25 03:19:52',NULL,'10f39112-111f-4c02-b6fa-bb1ea54ce2b1'),(4,'Author','author','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-11-25 04:18:45','2024-11-25 04:18:45','2024-11-25 04:20:50','a5db0b53-4e32-4a50-a747-6e96b7388483'),(5,'Author Name','authorName','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-11-25 04:20:57','2024-11-25 04:20:57',NULL,'58d0e1b7-5af0-4f28-bca5-6edc9448142f'),(6,'Category','category','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Categories','{\"allowSelfRelations\":false,\"branchLimit\":null,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":false,\"source\":\"group:d6ff0fc5-e079-4122-aee6-b52245a026e7\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-11-25 06:06:59','2024-11-25 06:06:59','2024-11-25 08:00:04','3faec832-2e61-4135-8515-f2c7ac8fd22d'),(7,'Image','image','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:71aefd52-fe8e-4c03-911c-8e5a2d7af4d5\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:71aefd52-fe8e-4c03-911c-8e5a2d7af4d5\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"cards\"}','2024-11-25 07:48:09','2024-11-25 07:48:09',NULL,'c06c82b2-36e3-48ec-bc99-31712ff69bbc'),(8,'Content Builder','contentBuilder','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":null,\"defaultIndexViewMode\":\"cards\",\"entryTypes\":[\"7356786d-81fd-47ec-9ab1-6fabc41ad7e1\",\"2c379949-8c14-4875-b5f0-162c720cb22d\"],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":null,\"pageSize\":50,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":false,\"viewMode\":\"cards\"}','2024-11-25 08:00:48','2024-11-25 08:05:13',NULL,'62347ed5-f9bc-4354-baa2-bb8670d74f11'),(9,'Padding','padding','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Top&Bottom\",\"value\":\"topBottom\",\"default\":\"1\"},{\"label\":\"Top\",\"value\":\"top\",\"default\":\"\"},{\"label\":\"Bottom\",\"value\":\"bottom\",\"default\":\"\"},{\"label\":\"None\",\"value\":\"none\",\"default\":\"\"}],\"customOptions\":false}','2024-11-25 08:17:30','2024-11-25 09:47:16',NULL,'e4262ebf-16b4-48e0-b742-08389f3b4024'),(10,'Reverse Layout','reverseLayout','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Lightswitch','{\"default\":false,\"offLabel\":null,\"onLabel\":null}','2024-11-25 08:24:34','2024-11-25 08:24:34',NULL,'f55f1621-c4b6-4e40-8696-f50eb42e5a13'),(11,'White Text','whiteText','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Lightswitch','{\"default\":false,\"offLabel\":null,\"onLabel\":null}','2024-11-25 08:24:52','2024-11-25 08:24:52',NULL,'80514974-1421-4e34-957e-49ae988dd7e5'),(12,'Heading','heading','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-11-25 08:28:35','2024-11-25 08:28:35',NULL,'588fd587-e28b-4dae-b639-4a550563c8f5'),(13,'Image Transforms','imageTransforms','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Dropdown','{\"customOptions\":false,\"options\":[{\"label\":\"Square\",\"value\":\"square\",\"default\":\"\"},{\"label\":\"None\",\"value\":\"\",\"default\":\"1\"},{\"label\":\"Thumbnail\",\"value\":\"thumbnail\",\"default\":\"\"}]}','2024-11-25 09:33:33','2024-11-25 09:34:15',NULL,'26bc567d-aa4e-4ba3-ae96-66859e54c1fa'),(14,'Background Colour','backgroundColour','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Color','{\"defaultColor\":null}','2024-11-25 09:35:07','2024-11-25 09:35:07','2024-11-25 09:45:41','5866d168-2370-409a-8438-a415c00d324d'),(15,'Width','width','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Dropdown','{\"customOptions\":false,\"options\":[{\"label\":\"Full Width\",\"value\":\"w-full\",\"default\":\"1\"},{\"label\":\"Half Width\",\"value\":\"lg:w-1\\/2\",\"default\":\"\"},{\"label\":\"Three Quarters\",\"value\":\"lg:w-3\\/4\",\"default\":\"\"},{\"label\":\"One Quarters\",\"value\":\"lg:w-1\\/4\",\"default\":\"\"}]}','2024-11-25 09:38:42','2024-11-25 09:38:42',NULL,'eba9d875-d930-4e6a-aa58-de4497f6fb96');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `imagetransforms` VALUES (1,'Thumbnail','thumbnail','crop','center-center',592,333,NULL,NULL,'none',NULL,1,'2024-11-25 06:14:52','2024-11-25 06:14:52','2024-11-25 06:14:52','c93c96a7-642c-465c-a35f-1386c8ff4be1'),(2,'Article Image','articleImage','crop','center-center',1008,567,NULL,NULL,'none',NULL,1,'2024-11-25 06:28:18','2024-11-25 06:28:18','2024-11-25 06:28:18','3b9d30c1-a93b-4268-a313-fd840d8f5ed9'),(3,'Square','square','crop','center-center',600,600,NULL,NULL,'none',NULL,1,'2024-11-25 09:36:54','2024-11-25 09:36:54','2024-11-25 09:36:54','e8835e60-5c9d-408d-816d-384b5dd8111f');
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'5.5.3','5.5.0.0',0,'gepbzojcgbxs','3@mhgczgeqtk','2024-11-24 20:04:52','2024-11-25 11:29:31','737f2061-cdee-4fc8-b274-f2016bc5877b');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,'craft','Install','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','6d229718-7c23-428e-9317-c9a356227f29'),(2,'craft','m221101_115859_create_entries_authors_table','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','86229add-b37b-4991-9e7e-fbba9d6ac448'),(3,'craft','m221107_112121_add_max_authors_to_sections','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','72ff7c88-2a0f-4502-99ce-468ce69c4beb'),(4,'craft','m221205_082005_translatable_asset_alt_text','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','40108c27-9924-42b6-a492-7ef685bde7d1'),(5,'craft','m230314_110309_add_authenticator_table','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','25652e01-99a8-4a24-beb9-76b2a32a6910'),(6,'craft','m230314_111234_add_webauthn_table','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','e90f9ac0-4127-4ac0-8c8d-f153a4bb639a'),(7,'craft','m230503_120303_add_recoverycodes_table','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','23df5307-4e36-43ad-9cc7-56962ae55337'),(8,'craft','m230511_000000_field_layout_configs','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','ca6a18ae-a2c2-4165-807e-6eebd7053f2b'),(9,'craft','m230511_215903_content_refactor','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','e1ad52df-5258-4090-b9b2-634ac96e0c31'),(10,'craft','m230524_000000_add_entry_type_show_slug_field','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','11911700-f984-4f8e-b4d4-ef4480f19441'),(11,'craft','m230524_000001_entry_type_icons','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','06d3e36e-4299-4a04-a0c2-319ac6adb330'),(12,'craft','m230524_000002_entry_type_colors','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','a1fbb0a7-fff7-4f8a-b0e6-7bdeed6d159c'),(13,'craft','m230524_220029_global_entry_types','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','6581c3ea-0b86-435b-8ac9-6ac73de3727f'),(14,'craft','m230531_123004_add_entry_type_show_status_field','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','cbb6f08d-a20f-4d98-8c94-3db520181c18'),(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','4646981d-d19d-44bb-b668-4ff801898ea4'),(16,'craft','m230616_173810_kill_field_groups','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','964d2cbb-93d1-47b1-ab6e-084e30712e9e'),(17,'craft','m230616_183820_remove_field_name_limit','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','847a0c89-0738-41db-b569-be2f13c8544b'),(18,'craft','m230617_070415_entrify_matrix_blocks','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','42e6dca1-4c18-44fc-83bd-0dda14cbcfff'),(19,'craft','m230710_162700_element_activity','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','fdd20ad4-878f-44c4-89fa-4d5cffac336f'),(20,'craft','m230820_162023_fix_cache_id_type','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','ae17d0ef-e840-48cf-8ed0-50d08861fa51'),(21,'craft','m230826_094050_fix_session_id_type','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','dc237f4f-3fe9-41e0-b18e-c4938193c535'),(22,'craft','m230904_190356_address_fields','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','8cd7e143-5960-4d44-9176-c4d9693d62f2'),(23,'craft','m230928_144045_add_subpath_to_volumes','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','8d16b9ac-ae85-4c0a-ae57-b5b2ae316b19'),(24,'craft','m231013_185640_changedfields_amend_primary_key','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','eaa0e575-ab76-49ad-b43c-6cad2c9989ac'),(25,'craft','m231213_030600_element_bulk_ops','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','e028f9d8-c1e0-4c69-b1d2-2a77ad5aca5a'),(26,'craft','m240129_150719_sites_language_amend_length','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','79864410-d45c-456d-99fc-96cdcfbf1ed7'),(27,'craft','m240206_035135_convert_json_columns','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','6f27772e-aeab-45c2-9c08-96db90b48399'),(28,'craft','m240207_182452_address_line_3','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','379cf837-3a32-400b-9d01-b4033cb9d0cf'),(29,'craft','m240302_212719_solo_preview_targets','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','fd7d3fa9-3d40-45b7-a6ec-480ed859b281'),(30,'craft','m240619_091352_add_auth_2fa_timestamp','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','7dcf9ffb-d596-4b33-87b7-e01c9c04e853'),(31,'craft','m240723_214330_drop_bulkop_fk','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','d6657d0d-3d2c-42a4-ab5a-9131ea062faf'),(32,'craft','m240731_053543_soft_delete_fields','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','29b3e19d-c1bf-44f6-920d-61cc70e66ee0'),(33,'craft','m240805_154041_sso_identities','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','8061ea03-0d67-40ef-ac7c-5bfc7754f279'),(34,'craft','m240926_202248_track_entries_deleted_with_section','2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-24 20:04:53','0a1c610e-695c-4df9-ac7c-5826768a2e63'),(35,'plugin:ckeditor','Install','2024-11-24 23:05:47','2024-11-24 23:05:47','2024-11-24 23:05:47','8680ab04-b58c-42cd-8d18-1637edefebe6'),(36,'plugin:ckeditor','m230408_163704_v3_upgrade','2024-11-24 23:05:47','2024-11-24 23:05:47','2024-11-24 23:05:47','d1419adf-3e68-4744-9abb-5ab2467f3cb9');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `plugins` VALUES (1,'ckeditor','4.4.0','3.0.0.0','2024-11-24 23:05:47','2024-11-24 23:05:47','2024-11-24 23:05:47','b6dafea8-a11b-4000-a016-1c441b06b815'),(2,'retcon','3.2.1','1.0.0','2024-11-25 01:37:15','2024-11-25 01:37:15','2024-11-25 01:37:15','dcf145e4-dff9-445d-b744-f69e6bfe9807');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES ('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.defaultPlacement','\"end\"'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elementCondition','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.autocapitalize','true'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.autocomplete','false'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.autocorrect','true'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.class','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.dateAdded','\"2024-11-25T06:05:01+00:00\"'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.disabled','false'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.elementCondition','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.id','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.includeInCards','false'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.inputType','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.instructions','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.label','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.max','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.min','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.name','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.orientation','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.placeholder','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.providesThumbs','false'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.readonly','false'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.requirable','false'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.size','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.step','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.tip','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.title','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\TitleField\"'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.uid','\"e7b9718d-06ed-4fd6-9b2b-e83cd6c13d99\"'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.userCondition','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.warning','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.elements.0.width','100'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.name','\"Content\"'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.uid','\"54210258-00be-4d54-bf6e-ec7d2ad50070\"'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.fieldLayouts.748548f5-00b4-4987-be07-2b2598644de1.tabs.0.userCondition','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.handle','\"news\"'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.name','\"News\"'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.siteSettings.1b2cf952-a9ed-486a-8dd8-be74115414cf.hasUrls','true'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.siteSettings.1b2cf952-a9ed-486a-8dd8-be74115414cf.template','\"news/_category.twig\"'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.siteSettings.1b2cf952-a9ed-486a-8dd8-be74115414cf.uriFormat','\"news/{slug}\"'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.structure.maxLevels','null'),('categoryGroups.d6ff0fc5-e079-4122-aee6-b52245a026e7.structure.uid','\"278bf2a3-008a-417a-a521-3c0a76c7cf6a\"'),('ckeditor.configs.228c56d6-4c4b-4de4-aa7b-385591661cda.headingLevels.0','1'),('ckeditor.configs.228c56d6-4c4b-4de4-aa7b-385591661cda.headingLevels.1','2'),('ckeditor.configs.228c56d6-4c4b-4de4-aa7b-385591661cda.headingLevels.2','3'),('ckeditor.configs.228c56d6-4c4b-4de4-aa7b-385591661cda.headingLevels.3','4'),('ckeditor.configs.228c56d6-4c4b-4de4-aa7b-385591661cda.headingLevels.4','5'),('ckeditor.configs.228c56d6-4c4b-4de4-aa7b-385591661cda.headingLevels.5','6'),('ckeditor.configs.228c56d6-4c4b-4de4-aa7b-385591661cda.name','\"Simple\"'),('ckeditor.configs.228c56d6-4c4b-4de4-aa7b-385591661cda.toolbar.0','\"heading\"'),('ckeditor.configs.228c56d6-4c4b-4de4-aa7b-385591661cda.toolbar.1','\"|\"'),('ckeditor.configs.228c56d6-4c4b-4de4-aa7b-385591661cda.toolbar.2','\"bold\"'),('ckeditor.configs.228c56d6-4c4b-4de4-aa7b-385591661cda.toolbar.3','\"italic\"'),('ckeditor.configs.228c56d6-4c4b-4de4-aa7b-385591661cda.toolbar.4','\"link\"'),('ckeditor.configs.263944d1-259b-4205-81b1-beac9e603be1.headingLevels.0','1'),('ckeditor.configs.263944d1-259b-4205-81b1-beac9e603be1.headingLevels.1','2'),('ckeditor.configs.263944d1-259b-4205-81b1-beac9e603be1.headingLevels.2','3'),('ckeditor.configs.263944d1-259b-4205-81b1-beac9e603be1.headingLevels.3','4'),('ckeditor.configs.263944d1-259b-4205-81b1-beac9e603be1.headingLevels.4','5'),('ckeditor.configs.263944d1-259b-4205-81b1-beac9e603be1.headingLevels.5','6'),('ckeditor.configs.263944d1-259b-4205-81b1-beac9e603be1.name','\"Full\"'),('ckeditor.configs.263944d1-259b-4205-81b1-beac9e603be1.toolbar.0','\"heading\"'),('ckeditor.configs.263944d1-259b-4205-81b1-beac9e603be1.toolbar.1','\"|\"'),('ckeditor.configs.263944d1-259b-4205-81b1-beac9e603be1.toolbar.2','\"bold\"'),('ckeditor.configs.263944d1-259b-4205-81b1-beac9e603be1.toolbar.3','\"italic\"'),('ckeditor.configs.263944d1-259b-4205-81b1-beac9e603be1.toolbar.4','\"link\"'),('dateModified','1732534171'),('email.fromEmail','\"abishekms7@gmail.com\"'),('email.fromName','\"Craft Site\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.color','\"blue\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elementCondition','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.autocapitalize','true'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.autocomplete','false'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.autocorrect','true'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.class','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.dateAdded','\"2024-11-25T08:00:01+00:00\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.disabled','false'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.elementCondition','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.id','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.includeInCards','false'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.inputType','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.instructions','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.label','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.max','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.min','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.name','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.orientation','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.placeholder','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.providesThumbs','false'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.readonly','false'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.required','true'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.size','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.step','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.tip','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.title','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.uid','\"84bdbcf1-c225-4a09-89e9-14a346676e72\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.userCondition','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.warning','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.0.width','100'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.1.dateAdded','\"2024-11-25T08:05:01+00:00\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.1.elementCondition','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.1.fieldUid','\"122ccab7-faba-4bd6-ade6-d9f5a4cc307b\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.1.handle','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.1.includeInCards','false'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.1.instructions','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.1.label','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.1.providesThumbs','false'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.1.required','false'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.1.tip','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.1.uid','\"9d42365a-b6cc-4efa-9e21-75d0485f4e2e\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.1.userCondition','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.1.warning','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.1.width','100'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.2.dateAdded','\"2024-11-25T09:41:20+00:00\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.2.elementCondition','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.2.fieldUid','\"eba9d875-d930-4e6a-aa58-de4497f6fb96\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.2.handle','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.2.includeInCards','false'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.2.instructions','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.2.label','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.2.providesThumbs','false'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.2.required','false'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.2.tip','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.2.uid','\"e135c047-9b8d-4aa0-990f-1bc9a5bf96c2\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.2.userCondition','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.2.warning','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.2.width','100'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.3.dateAdded','\"2024-11-25T08:17:48+00:00\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.3.elementCondition','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.3.fieldUid','\"e4262ebf-16b4-48e0-b742-08389f3b4024\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.3.handle','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.3.includeInCards','false'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.3.instructions','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.3.label','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.3.providesThumbs','false'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.3.required','false'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.3.tip','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.3.uid','\"e5c64962-e6a2-4fe2-89dc-08babd909c58\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.3.userCondition','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.3.warning','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.elements.3.width','100'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.name','\"Content\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.uid','\"f3b77598-e466-4aea-8141-ac5ccb36f268\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.fieldLayouts.6104a56a-762e-4da1-9546-1e40b60bdc3a.tabs.0.userCondition','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.handle','\"richText\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.hasTitleField','true'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.icon','\"text\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.name','\"Rich Text\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.showSlugField','true'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.showStatusField','true'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.slugTranslationKeyFormat','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.slugTranslationMethod','\"site\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.titleFormat','\"\"'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.titleTranslationKeyFormat','null'),('entryTypes.2c379949-8c14-4875-b5f0-162c720cb22d.titleTranslationMethod','\"site\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.color','\"orange\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elementCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.autocapitalize','true'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.autocomplete','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.autocorrect','true'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.class','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.dateAdded','\"2024-11-25T07:58:12+00:00\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.disabled','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.elementCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.id','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.includeInCards','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.inputType','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.instructions','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.label','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.max','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.min','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.name','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.orientation','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.placeholder','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.providesThumbs','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.readonly','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.required','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.size','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.step','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.tip','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.title','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.uid','\"5218cad8-a88c-4921-9247-2299cef4ef83\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.userCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.warning','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.0.width','100'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.1.dateAdded','\"2024-11-25T07:59:52+00:00\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.1.elementCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.1.fieldUid','\"c06c82b2-36e3-48ec-bc99-31712ff69bbc\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.1.handle','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.1.includeInCards','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.1.instructions','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.1.label','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.1.providesThumbs','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.1.required','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.1.tip','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.1.uid','\"26485dda-4e20-482f-8fa7-f425bc00b47c\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.1.userCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.1.warning','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.1.width','100'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.2.dateAdded','\"2024-11-25T08:28:48+00:00\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.2.elementCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.2.fieldUid','\"588fd587-e28b-4dae-b639-4a550563c8f5\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.2.handle','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.2.includeInCards','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.2.instructions','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.2.label','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.2.providesThumbs','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.2.required','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.2.tip','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.2.uid','\"ee4daa79-ca03-488a-b6ff-87f6f1f057c9\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.2.userCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.2.warning','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.2.width','100'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.3.dateAdded','\"2024-11-25T07:59:52+00:00\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.3.elementCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.3.fieldUid','\"122ccab7-faba-4bd6-ade6-d9f5a4cc307b\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.3.handle','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.3.includeInCards','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.3.instructions','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.3.label','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.3.providesThumbs','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.3.required','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.3.tip','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.3.uid','\"7af9c571-2e53-49ba-acc8-4a7d3d9e9cb2\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.3.userCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.3.warning','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.elements.3.width','100'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.name','\"Content\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.uid','\"f59ce6cd-039a-4b1e-a119-89263fa0bc20\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.0.userCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elementCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.0.dateAdded','\"2024-11-25T09:34:44+00:00\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.0.elementCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.0.fieldUid','\"26bc567d-aa4e-4ba3-ae96-66859e54c1fa\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.0.handle','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.0.includeInCards','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.0.instructions','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.0.label','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.0.providesThumbs','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.0.required','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.0.tip','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.0.uid','\"d4503cda-f661-4454-966e-39d12d4bc8cb\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.0.userCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.0.warning','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.0.width','50'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.1.dateAdded','\"2024-11-25T08:25:12+00:00\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.1.elementCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.1.fieldUid','\"f55f1621-c4b6-4e40-8696-f50eb42e5a13\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.1.handle','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.1.includeInCards','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.1.instructions','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.1.label','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.1.providesThumbs','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.1.required','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.1.tip','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.1.uid','\"3cba98e0-5c15-4a0f-939b-18e23cdd05fb\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.1.userCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.1.warning','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.1.width','50'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.2.dateAdded','\"2024-11-25T08:25:12+00:00\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.2.elementCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.2.fieldUid','\"80514974-1421-4e34-957e-49ae988dd7e5\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.2.handle','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.2.includeInCards','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.2.instructions','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.2.label','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.2.providesThumbs','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.2.required','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.2.tip','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.2.uid','\"90d47f07-a348-4cf6-b54c-52b94b7e3b2c\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.2.userCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.2.warning','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.2.width','50'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.3.dateAdded','\"2024-11-25T09:48:23+00:00\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.3.elementCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.3.fieldUid','\"e4262ebf-16b4-48e0-b742-08389f3b4024\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.3.handle','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.3.includeInCards','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.3.instructions','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.3.label','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.3.providesThumbs','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.3.required','false'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.3.tip','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.3.uid','\"82ca84f7-6361-4afc-99ce-7d1001f0544b\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.3.userCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.3.warning','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.elements.3.width','50'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.name','\"Settings\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.uid','\"5a1bcacf-7547-4396-a5c5-a968d726a08e\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.fieldLayouts.eac0d05b-6b34-42f5-a7b0-a7a5f4dbeffa.tabs.1.userCondition','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.handle','\"imageAndText\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.hasTitleField','true'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.icon','\"image-landscape\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.name','\"Image and Text\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.showSlugField','true'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.showStatusField','true'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.slugTranslationKeyFormat','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.slugTranslationMethod','\"site\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.titleFormat','\"\"'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.titleTranslationKeyFormat','null'),('entryTypes.7356786d-81fd-47ec-9ab1-6fabc41ad7e1.titleTranslationMethod','\"site\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.color','\"green\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elementCondition','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.autocapitalize','true'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.autocomplete','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.autocorrect','true'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.class','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.dateAdded','\"2024-11-24T20:06:51+00:00\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.disabled','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.elementCondition','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.id','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.includeInCards','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.inputType','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.instructions','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.label','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.max','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.min','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.name','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.orientation','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.placeholder','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.providesThumbs','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.readonly','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.required','true'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.size','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.step','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.tip','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.title','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.uid','\"d0f8b4b9-9a1a-416e-863f-ffcd38010984\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.userCondition','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.warning','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.0.width','100'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.1.dateAdded','\"2024-11-24T23:58:49+00:00\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.1.elementCondition','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.1.fieldUid','\"419eeb43-dd1b-4802-8e8a-db25a812d596\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.1.handle','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.1.includeInCards','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.1.instructions','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.1.label','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.1.providesThumbs','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.1.required','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.1.tip','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.1.uid','\"8543a8ed-d05a-4df4-90d0-df04c2b06519\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.1.userCondition','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.1.warning','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.1.width','100'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.2.dateAdded','\"2024-11-25T04:21:19+00:00\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.2.elementCondition','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.2.fieldUid','\"58d0e1b7-5af0-4f28-bca5-6edc9448142f\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.2.handle','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.2.includeInCards','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.2.instructions','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.2.label','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.2.providesThumbs','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.2.required','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.2.tip','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.2.uid','\"9dae6c46-66cf-472c-b670-d6da3fe8e56f\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.2.userCondition','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.2.warning','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.2.width','100'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.3.dateAdded','\"2024-11-25T03:20:12+00:00\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.3.elementCondition','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.3.fieldUid','\"10f39112-111f-4c02-b6fa-bb1ea54ce2b1\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.3.handle','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.3.includeInCards','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.3.instructions','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.3.label','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.3.providesThumbs','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.3.required','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.3.tip','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.3.uid','\"735b9e7b-1762-4b48-89f1-5416895bd6d3\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.3.userCondition','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.3.warning','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.3.width','100'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.4.dateAdded','\"2024-11-25T07:57:16+00:00\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.4.elementCondition','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\HorizontalRule\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.4.uid','\"6caae44c-272d-4768-85f7-4f5fbd905987\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.4.userCondition','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.5.dateAdded','\"2024-11-25T08:05:52+00:00\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.5.elementCondition','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.5.fieldUid','\"62347ed5-f9bc-4354-baa2-bb8670d74f11\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.5.handle','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.5.includeInCards','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.5.instructions','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.5.label','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.5.providesThumbs','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.5.required','false'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.5.tip','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.5.uid','\"bf470c7f-7dc5-4e40-a119-ff14f27a0d73\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.5.userCondition','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.5.warning','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.elements.5.width','100'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.name','\"Content\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.uid','\"4b91be54-f1fc-4f1f-813b-45e5f5565205\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.fieldLayouts.c3eefcf3-0257-45b3-bea9-b8be77bb73f3.tabs.0.userCondition','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.handle','\"news\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.hasTitleField','true'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.icon','\"newspaper\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.name','\"News\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.showSlugField','true'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.showStatusField','true'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.slugTranslationKeyFormat','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.slugTranslationMethod','\"site\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.titleFormat','\"\"'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.titleTranslationKeyFormat','null'),('entryTypes.f0df6858-5d8c-4812-bf89-b17c116385b5.titleTranslationMethod','\"site\"'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.color','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elementCondition','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.autocapitalize','true'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.autocomplete','false'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.autocorrect','true'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.class','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.dateAdded','\"2024-11-24T20:59:01+00:00\"'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.disabled','false'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.elementCondition','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.id','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.includeInCards','false'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.inputType','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.instructions','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.label','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.max','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.min','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.name','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.orientation','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.placeholder','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.providesThumbs','false'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.readonly','false'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.required','true'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.size','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.step','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.tip','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.title','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.uid','\"da20dd65-7a00-4847-a8e3-a9aed580db55\"'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.userCondition','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.warning','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.elements.0.width','100'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.name','\"Content\"'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.uid','\"5bc78c10-aebb-4449-8d83-58b05d645253\"'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.fieldLayouts.5dd5e2dd-0db5-469d-8db9-a182290f88d6.tabs.0.userCondition','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.handle','\"homepage\"'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.hasTitleField','true'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.icon','\"\"'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.name','\"Homepage\"'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.showSlugField','true'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.showStatusField','true'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.slugTranslationKeyFormat','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.slugTranslationMethod','\"site\"'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.titleFormat','\"\"'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.titleTranslationKeyFormat','null'),('entryTypes.fcaabefb-5d4e-44ae-a74b-f34412522982.titleTranslationMethod','\"site\"'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.columnSuffix','null'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.handle','\"description\"'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.instructions','null'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.name','\"Description\"'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.searchable','false'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.settings.availableTransforms','\"\"'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.settings.availableVolumes','\"*\"'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.settings.ckeConfig','\"263944d1-259b-4205-81b1-beac9e603be1\"'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.settings.createButtonLabel','null'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.settings.defaultTransform','null'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.settings.enableSourceEditingForNonAdmins','false'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.settings.purifierConfig','null'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.settings.purifyHtml','true'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.settings.showUnpermittedFiles','false'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.settings.showUnpermittedVolumes','false'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.settings.showWordCount','false'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.settings.wordLimit','null'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.translationKeyFormat','null'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.translationMethod','\"none\"'),('fields.10f39112-111f-4c02-b6fa-bb1ea54ce2b1.type','\"craft\\\\ckeditor\\\\Field\"'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.columnSuffix','null'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.handle','\"text\"'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.instructions','null'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.name','\"Text\"'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.searchable','false'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.settings.availableTransforms','\"\"'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.settings.availableVolumes','\"\"'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.settings.ckeConfig','\"228c56d6-4c4b-4de4-aa7b-385591661cda\"'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.settings.createButtonLabel','null'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.settings.defaultTransform','null'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.settings.enableSourceEditingForNonAdmins','false'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.settings.purifierConfig','null'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.settings.purifyHtml','true'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.settings.showUnpermittedFiles','false'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.settings.showUnpermittedVolumes','false'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.settings.showWordCount','false'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.settings.wordLimit','null'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.translationKeyFormat','null'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.translationMethod','\"none\"'),('fields.122ccab7-faba-4bd6-ade6-d9f5a4cc307b.type','\"craft\\\\ckeditor\\\\Field\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.columnSuffix','null'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.handle','\"imageTransforms\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.instructions','null'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.name','\"Image Transforms\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.searchable','false'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.customOptions','false'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.0.__assoc__.0.0','\"label\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.0.__assoc__.0.1','\"Square\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.0.__assoc__.1.0','\"value\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.0.__assoc__.1.1','\"square\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.0.__assoc__.2.0','\"default\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.0.__assoc__.2.1','\"\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.1.__assoc__.0.0','\"label\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.1.__assoc__.0.1','\"None\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.1.__assoc__.1.0','\"value\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.1.__assoc__.1.1','\"\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.1.__assoc__.2.0','\"default\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.1.__assoc__.2.1','\"1\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.2.__assoc__.0.0','\"label\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.2.__assoc__.0.1','\"Thumbnail\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.2.__assoc__.1.0','\"value\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.2.__assoc__.1.1','\"thumbnail\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.2.__assoc__.2.0','\"default\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.settings.options.2.__assoc__.2.1','\"\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.translationKeyFormat','null'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.translationMethod','\"none\"'),('fields.26bc567d-aa4e-4ba3-ae96-66859e54c1fa.type','\"craft\\\\fields\\\\Dropdown\"'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.columnSuffix','null'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.handle','\"mainImage\"'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.instructions','null'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.name','\"Main Image\"'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.searchable','false'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.allowedKinds','null'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.allowSelfRelations','false'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.allowSubfolders','false'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.allowUploads','true'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.branchLimit','null'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.defaultUploadLocationSource','\"volume:71aefd52-fe8e-4c03-911c-8e5a2d7af4d5\"'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.defaultUploadLocationSubpath','null'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.maintainHierarchy','false'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.maxRelations','1'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.minRelations','1'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.previewMode','\"full\"'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.restrictedDefaultUploadSubpath','null'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.restrictedLocationSource','\"volume:71aefd52-fe8e-4c03-911c-8e5a2d7af4d5\"'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.restrictedLocationSubpath','null'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.restrictFiles','false'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.restrictLocation','false'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.selectionLabel','null'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.showCardsInGrid','false'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.showSiteMenu','true'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.showUnpermittedFiles','false'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.showUnpermittedVolumes','false'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.sources','\"*\"'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.targetSiteId','null'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.validateRelatedElements','false'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.settings.viewMode','\"list\"'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.translationKeyFormat','null'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.translationMethod','\"none\"'),('fields.419eeb43-dd1b-4802-8e8a-db25a812d596.type','\"craft\\\\fields\\\\Assets\"'),('fields.588fd587-e28b-4dae-b639-4a550563c8f5.columnSuffix','null'),('fields.588fd587-e28b-4dae-b639-4a550563c8f5.handle','\"heading\"'),('fields.588fd587-e28b-4dae-b639-4a550563c8f5.instructions','null'),('fields.588fd587-e28b-4dae-b639-4a550563c8f5.name','\"Heading\"'),('fields.588fd587-e28b-4dae-b639-4a550563c8f5.searchable','false'),('fields.588fd587-e28b-4dae-b639-4a550563c8f5.settings.byteLimit','null'),('fields.588fd587-e28b-4dae-b639-4a550563c8f5.settings.charLimit','null'),('fields.588fd587-e28b-4dae-b639-4a550563c8f5.settings.code','false'),('fields.588fd587-e28b-4dae-b639-4a550563c8f5.settings.initialRows','4'),('fields.588fd587-e28b-4dae-b639-4a550563c8f5.settings.multiline','false'),('fields.588fd587-e28b-4dae-b639-4a550563c8f5.settings.placeholder','null'),('fields.588fd587-e28b-4dae-b639-4a550563c8f5.settings.uiMode','\"normal\"'),('fields.588fd587-e28b-4dae-b639-4a550563c8f5.translationKeyFormat','null'),('fields.588fd587-e28b-4dae-b639-4a550563c8f5.translationMethod','\"none\"'),('fields.588fd587-e28b-4dae-b639-4a550563c8f5.type','\"craft\\\\fields\\\\PlainText\"'),('fields.58d0e1b7-5af0-4f28-bca5-6edc9448142f.columnSuffix','null'),('fields.58d0e1b7-5af0-4f28-bca5-6edc9448142f.handle','\"authorName\"'),('fields.58d0e1b7-5af0-4f28-bca5-6edc9448142f.instructions','null'),('fields.58d0e1b7-5af0-4f28-bca5-6edc9448142f.name','\"Author Name\"'),('fields.58d0e1b7-5af0-4f28-bca5-6edc9448142f.searchable','false'),('fields.58d0e1b7-5af0-4f28-bca5-6edc9448142f.settings.byteLimit','null'),('fields.58d0e1b7-5af0-4f28-bca5-6edc9448142f.settings.charLimit','null'),('fields.58d0e1b7-5af0-4f28-bca5-6edc9448142f.settings.code','false'),('fields.58d0e1b7-5af0-4f28-bca5-6edc9448142f.settings.initialRows','4'),('fields.58d0e1b7-5af0-4f28-bca5-6edc9448142f.settings.multiline','false'),('fields.58d0e1b7-5af0-4f28-bca5-6edc9448142f.settings.placeholder','null'),('fields.58d0e1b7-5af0-4f28-bca5-6edc9448142f.settings.uiMode','\"normal\"'),('fields.58d0e1b7-5af0-4f28-bca5-6edc9448142f.translationKeyFormat','null'),('fields.58d0e1b7-5af0-4f28-bca5-6edc9448142f.translationMethod','\"none\"'),('fields.58d0e1b7-5af0-4f28-bca5-6edc9448142f.type','\"craft\\\\fields\\\\PlainText\"'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.columnSuffix','null'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.handle','\"contentBuilder\"'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.instructions','null'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.name','\"Content Builder\"'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.searchable','false'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.settings.createButtonLabel','null'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.settings.defaultIndexViewMode','\"cards\"'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.settings.entryTypes.0','\"7356786d-81fd-47ec-9ab1-6fabc41ad7e1\"'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.settings.entryTypes.1','\"2c379949-8c14-4875-b5f0-162c720cb22d\"'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.settings.includeTableView','false'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.settings.maxEntries','null'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.settings.minEntries','null'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.settings.pageSize','50'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.settings.propagationKeyFormat','null'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.settings.propagationMethod','\"all\"'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.settings.showCardsInGrid','false'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.settings.viewMode','\"cards\"'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.translationKeyFormat','null'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.translationMethod','\"site\"'),('fields.62347ed5-f9bc-4354-baa2-bb8670d74f11.type','\"craft\\\\fields\\\\Matrix\"'),('fields.80514974-1421-4e34-957e-49ae988dd7e5.columnSuffix','null'),('fields.80514974-1421-4e34-957e-49ae988dd7e5.handle','\"whiteText\"'),('fields.80514974-1421-4e34-957e-49ae988dd7e5.instructions','null'),('fields.80514974-1421-4e34-957e-49ae988dd7e5.name','\"White Text\"'),('fields.80514974-1421-4e34-957e-49ae988dd7e5.searchable','false'),('fields.80514974-1421-4e34-957e-49ae988dd7e5.settings.default','false'),('fields.80514974-1421-4e34-957e-49ae988dd7e5.settings.offLabel','null'),('fields.80514974-1421-4e34-957e-49ae988dd7e5.settings.onLabel','null'),('fields.80514974-1421-4e34-957e-49ae988dd7e5.translationKeyFormat','null'),('fields.80514974-1421-4e34-957e-49ae988dd7e5.translationMethod','\"none\"'),('fields.80514974-1421-4e34-957e-49ae988dd7e5.type','\"craft\\\\fields\\\\Lightswitch\"'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.columnSuffix','null'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.handle','\"image\"'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.instructions','null'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.name','\"Image\"'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.searchable','false'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.allowedKinds','null'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.allowSelfRelations','false'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.allowSubfolders','false'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.allowUploads','true'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.branchLimit','null'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.defaultUploadLocationSource','\"volume:71aefd52-fe8e-4c03-911c-8e5a2d7af4d5\"'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.defaultUploadLocationSubpath','null'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.maintainHierarchy','false'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.maxRelations','1'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.minRelations','1'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.previewMode','\"full\"'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.restrictedDefaultUploadSubpath','null'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.restrictedLocationSource','\"volume:71aefd52-fe8e-4c03-911c-8e5a2d7af4d5\"'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.restrictedLocationSubpath','null'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.restrictFiles','false'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.restrictLocation','false'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.selectionLabel','null'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.showCardsInGrid','false'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.showSiteMenu','false'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.showUnpermittedFiles','false'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.showUnpermittedVolumes','false'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.sources','\"*\"'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.targetSiteId','null'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.validateRelatedElements','false'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.settings.viewMode','\"cards\"'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.translationKeyFormat','null'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.translationMethod','\"none\"'),('fields.c06c82b2-36e3-48ec-bc99-31712ff69bbc.type','\"craft\\\\fields\\\\Assets\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.columnSuffix','null'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.handle','\"padding\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.instructions','null'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.name','\"Padding\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.searchable','false'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.customOptions','false'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.0.__assoc__.0.0','\"label\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.0.__assoc__.0.1','\"Top&Bottom\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.0.__assoc__.1.0','\"value\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.0.__assoc__.1.1','\"topBottom\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.0.__assoc__.2.0','\"default\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.0.__assoc__.2.1','\"1\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.1.__assoc__.0.0','\"label\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.1.__assoc__.0.1','\"Top\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.1.__assoc__.1.0','\"value\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.1.__assoc__.1.1','\"top\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.1.__assoc__.2.0','\"default\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.1.__assoc__.2.1','\"\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.2.__assoc__.0.0','\"label\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.2.__assoc__.0.1','\"Bottom\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.2.__assoc__.1.0','\"value\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.2.__assoc__.1.1','\"bottom\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.2.__assoc__.2.0','\"default\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.2.__assoc__.2.1','\"\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.3.__assoc__.0.0','\"label\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.3.__assoc__.0.1','\"None\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.3.__assoc__.1.0','\"value\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.3.__assoc__.1.1','\"none\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.3.__assoc__.2.0','\"default\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.settings.options.3.__assoc__.2.1','\"\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.translationKeyFormat','null'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.translationMethod','\"none\"'),('fields.e4262ebf-16b4-48e0-b742-08389f3b4024.type','\"craft\\\\fields\\\\Dropdown\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.columnSuffix','null'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.handle','\"width\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.instructions','null'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.name','\"Width\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.searchable','false'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.customOptions','false'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.0.__assoc__.0.0','\"label\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.0.__assoc__.0.1','\"Full Width\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.0.__assoc__.1.0','\"value\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.0.__assoc__.1.1','\"w-full\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.0.__assoc__.2.0','\"default\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.0.__assoc__.2.1','\"1\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.1.__assoc__.0.0','\"label\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.1.__assoc__.0.1','\"Half Width\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.1.__assoc__.1.0','\"value\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.1.__assoc__.1.1','\"lg:w-1/2\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.1.__assoc__.2.0','\"default\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.1.__assoc__.2.1','\"\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.2.__assoc__.0.0','\"label\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.2.__assoc__.0.1','\"Three Quarters\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.2.__assoc__.1.0','\"value\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.2.__assoc__.1.1','\"lg:w-3/4\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.2.__assoc__.2.0','\"default\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.2.__assoc__.2.1','\"\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.3.__assoc__.0.0','\"label\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.3.__assoc__.0.1','\"One Quarters\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.3.__assoc__.1.0','\"value\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.3.__assoc__.1.1','\"lg:w-1/4\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.3.__assoc__.2.0','\"default\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.settings.options.3.__assoc__.2.1','\"\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.translationKeyFormat','null'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.translationMethod','\"none\"'),('fields.eba9d875-d930-4e6a-aa58-de4497f6fb96.type','\"craft\\\\fields\\\\Dropdown\"'),('fields.f55f1621-c4b6-4e40-8696-f50eb42e5a13.columnSuffix','null'),('fields.f55f1621-c4b6-4e40-8696-f50eb42e5a13.handle','\"reverseLayout\"'),('fields.f55f1621-c4b6-4e40-8696-f50eb42e5a13.instructions','null'),('fields.f55f1621-c4b6-4e40-8696-f50eb42e5a13.name','\"Reverse Layout\"'),('fields.f55f1621-c4b6-4e40-8696-f50eb42e5a13.searchable','false'),('fields.f55f1621-c4b6-4e40-8696-f50eb42e5a13.settings.default','false'),('fields.f55f1621-c4b6-4e40-8696-f50eb42e5a13.settings.offLabel','null'),('fields.f55f1621-c4b6-4e40-8696-f50eb42e5a13.settings.onLabel','null'),('fields.f55f1621-c4b6-4e40-8696-f50eb42e5a13.translationKeyFormat','null'),('fields.f55f1621-c4b6-4e40-8696-f50eb42e5a13.translationMethod','\"none\"'),('fields.f55f1621-c4b6-4e40-8696-f50eb42e5a13.type','\"craft\\\\fields\\\\Lightswitch\"'),('fs.assets.hasUrls','true'),('fs.assets.name','\"Assets\"'),('fs.assets.settings.path','\"$PRIMARY_ASSETS_PATH\"'),('fs.assets.type','\"craft\\\\fs\\\\Local\"'),('fs.assets.url','\"$PRIMARY_ASSETS_URL\"'),('fs.uploads.hasUrls','true'),('fs.uploads.name','\"Uploads\"'),('fs.uploads.settings.path','\"@webroot/uploads\"'),('fs.uploads.type','\"craft\\\\fs\\\\Local\"'),('fs.uploads.url','\"$PRIMARY_ASSETS_URL\"'),('imageTransforms.3b9d30c1-a93b-4268-a313-fd840d8f5ed9.fill','null'),('imageTransforms.3b9d30c1-a93b-4268-a313-fd840d8f5ed9.format','null'),('imageTransforms.3b9d30c1-a93b-4268-a313-fd840d8f5ed9.handle','\"articleImage\"'),('imageTransforms.3b9d30c1-a93b-4268-a313-fd840d8f5ed9.height','567'),('imageTransforms.3b9d30c1-a93b-4268-a313-fd840d8f5ed9.interlace','\"none\"'),('imageTransforms.3b9d30c1-a93b-4268-a313-fd840d8f5ed9.mode','\"crop\"'),('imageTransforms.3b9d30c1-a93b-4268-a313-fd840d8f5ed9.name','\"Article Image\"'),('imageTransforms.3b9d30c1-a93b-4268-a313-fd840d8f5ed9.position','\"center-center\"'),('imageTransforms.3b9d30c1-a93b-4268-a313-fd840d8f5ed9.quality','null'),('imageTransforms.3b9d30c1-a93b-4268-a313-fd840d8f5ed9.upscale','true'),('imageTransforms.3b9d30c1-a93b-4268-a313-fd840d8f5ed9.width','1008'),('imageTransforms.c93c96a7-642c-465c-a35f-1386c8ff4be1.fill','null'),('imageTransforms.c93c96a7-642c-465c-a35f-1386c8ff4be1.format','null'),('imageTransforms.c93c96a7-642c-465c-a35f-1386c8ff4be1.handle','\"thumbnail\"'),('imageTransforms.c93c96a7-642c-465c-a35f-1386c8ff4be1.height','333'),('imageTransforms.c93c96a7-642c-465c-a35f-1386c8ff4be1.interlace','\"none\"'),('imageTransforms.c93c96a7-642c-465c-a35f-1386c8ff4be1.mode','\"crop\"'),('imageTransforms.c93c96a7-642c-465c-a35f-1386c8ff4be1.name','\"Thumbnail\"'),('imageTransforms.c93c96a7-642c-465c-a35f-1386c8ff4be1.position','\"center-center\"'),('imageTransforms.c93c96a7-642c-465c-a35f-1386c8ff4be1.quality','null'),('imageTransforms.c93c96a7-642c-465c-a35f-1386c8ff4be1.upscale','true'),('imageTransforms.c93c96a7-642c-465c-a35f-1386c8ff4be1.width','592'),('imageTransforms.e8835e60-5c9d-408d-816d-384b5dd8111f.fill','null'),('imageTransforms.e8835e60-5c9d-408d-816d-384b5dd8111f.format','null'),('imageTransforms.e8835e60-5c9d-408d-816d-384b5dd8111f.handle','\"square\"'),('imageTransforms.e8835e60-5c9d-408d-816d-384b5dd8111f.height','600'),('imageTransforms.e8835e60-5c9d-408d-816d-384b5dd8111f.interlace','\"none\"'),('imageTransforms.e8835e60-5c9d-408d-816d-384b5dd8111f.mode','\"crop\"'),('imageTransforms.e8835e60-5c9d-408d-816d-384b5dd8111f.name','\"Square\"'),('imageTransforms.e8835e60-5c9d-408d-816d-384b5dd8111f.position','\"center-center\"'),('imageTransforms.e8835e60-5c9d-408d-816d-384b5dd8111f.quality','null'),('imageTransforms.e8835e60-5c9d-408d-816d-384b5dd8111f.upscale','true'),('imageTransforms.e8835e60-5c9d-408d-816d-384b5dd8111f.width','600'),('meta.__names__.10f39112-111f-4c02-b6fa-bb1ea54ce2b1','\"Description\"'),('meta.__names__.122ccab7-faba-4bd6-ade6-d9f5a4cc307b','\"Text\"'),('meta.__names__.1b2cf952-a9ed-486a-8dd8-be74115414cf','\"Craft Site\"'),('meta.__names__.228c56d6-4c4b-4de4-aa7b-385591661cda','\"Simple\"'),('meta.__names__.263944d1-259b-4205-81b1-beac9e603be1','\"Full\"'),('meta.__names__.26bc567d-aa4e-4ba3-ae96-66859e54c1fa','\"Image Transforms\"'),('meta.__names__.2c379949-8c14-4875-b5f0-162c720cb22d','\"Rich Text\"'),('meta.__names__.3b9d30c1-a93b-4268-a313-fd840d8f5ed9','\"Article Image\"'),('meta.__names__.419eeb43-dd1b-4802-8e8a-db25a812d596','\"Main Image\"'),('meta.__names__.588fd587-e28b-4dae-b639-4a550563c8f5','\"Heading\"'),('meta.__names__.58d0e1b7-5af0-4f28-bca5-6edc9448142f','\"Author Name\"'),('meta.__names__.62347ed5-f9bc-4354-baa2-bb8670d74f11','\"Content Builder\"'),('meta.__names__.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5','\"Assets\"'),('meta.__names__.721c4a33-2c28-47e7-b769-8356d8257154','\"Craft Site\"'),('meta.__names__.7356786d-81fd-47ec-9ab1-6fabc41ad7e1','\"Image and Text\"'),('meta.__names__.80514974-1421-4e34-957e-49ae988dd7e5','\"White Text\"'),('meta.__names__.98b466bb-97e7-448e-84a2-84a802931afd','\"News\"'),('meta.__names__.c06c82b2-36e3-48ec-bc99-31712ff69bbc','\"Image\"'),('meta.__names__.c93c96a7-642c-465c-a35f-1386c8ff4be1','\"Thumbnail\"'),('meta.__names__.d6ff0fc5-e079-4122-aee6-b52245a026e7','\"News\"'),('meta.__names__.e4262ebf-16b4-48e0-b742-08389f3b4024','\"Padding\"'),('meta.__names__.e8835e60-5c9d-408d-816d-384b5dd8111f','\"Square\"'),('meta.__names__.eba9d875-d930-4e6a-aa58-de4497f6fb96','\"Width\"'),('meta.__names__.f0df6858-5d8c-4812-bf89-b17c116385b5','\"News\"'),('meta.__names__.f55f1621-c4b6-4e40-8696-f50eb42e5a13','\"Reverse Layout\"'),('meta.__names__.fcaabefb-5d4e-44ae-a74b-f34412522982','\"Homepage\"'),('meta.__names__.fe86b1d3-9192-4dcd-ae58-c17f6b392a74','\"Homepage\"'),('plugins.ckeditor.edition','\"standard\"'),('plugins.ckeditor.enabled','true'),('plugins.ckeditor.schemaVersion','\"3.0.0.0\"'),('plugins.retcon.edition','\"standard\"'),('plugins.retcon.enabled','true'),('plugins.retcon.schemaVersion','\"1.0.0\"'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.defaultPlacement','\"end\"'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.enableVersioning','true'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.entryTypes.0','\"f0df6858-5d8c-4812-bf89-b17c116385b5\"'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.handle','\"news\"'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.maxAuthors','1'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.name','\"News\"'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.propagationMethod','\"all\"'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.siteSettings.1b2cf952-a9ed-486a-8dd8-be74115414cf.enabledByDefault','true'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.siteSettings.1b2cf952-a9ed-486a-8dd8-be74115414cf.hasUrls','true'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.siteSettings.1b2cf952-a9ed-486a-8dd8-be74115414cf.template','\"news/_entry.twig\"'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.siteSettings.1b2cf952-a9ed-486a-8dd8-be74115414cf.uriFormat','\"news/{slug}\"'),('sections.98b466bb-97e7-448e-84a2-84a802931afd.type','\"channel\"'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.defaultPlacement','\"end\"'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.enableVersioning','true'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.entryTypes.0','\"fcaabefb-5d4e-44ae-a74b-f34412522982\"'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.handle','\"homepage\"'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.maxAuthors','1'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.name','\"Homepage\"'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.propagationMethod','\"all\"'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.siteSettings.1b2cf952-a9ed-486a-8dd8-be74115414cf.enabledByDefault','true'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.siteSettings.1b2cf952-a9ed-486a-8dd8-be74115414cf.hasUrls','true'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.siteSettings.1b2cf952-a9ed-486a-8dd8-be74115414cf.template','\"homepage/_entry.twig\"'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.siteSettings.1b2cf952-a9ed-486a-8dd8-be74115414cf.uriFormat','\"homepage\"'),('sections.fe86b1d3-9192-4dcd-ae58-c17f6b392a74.type','\"single\"'),('siteGroups.721c4a33-2c28-47e7-b769-8356d8257154.name','\"Craft Site\"'),('sites.1b2cf952-a9ed-486a-8dd8-be74115414cf.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.1b2cf952-a9ed-486a-8dd8-be74115414cf.handle','\"default\"'),('sites.1b2cf952-a9ed-486a-8dd8-be74115414cf.hasUrls','true'),('sites.1b2cf952-a9ed-486a-8dd8-be74115414cf.language','\"en-US\"'),('sites.1b2cf952-a9ed-486a-8dd8-be74115414cf.name','\"Craft Site\"'),('sites.1b2cf952-a9ed-486a-8dd8-be74115414cf.primary','true'),('sites.1b2cf952-a9ed-486a-8dd8-be74115414cf.siteGroup','\"721c4a33-2c28-47e7-b769-8356d8257154\"'),('sites.1b2cf952-a9ed-486a-8dd8-be74115414cf.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"Test Site\"'),('system.retryDuration','null'),('system.schemaVersion','\"5.5.0.0\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.altTranslationKeyFormat','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.altTranslationMethod','\"none\"'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elementCondition','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.autocapitalize','true'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.autocomplete','false'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.autocorrect','true'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.class','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.dateAdded','\"2024-11-25T00:27:42+00:00\"'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.disabled','false'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.elementCondition','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.id','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.includeInCards','false'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.inputType','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.instructions','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.label','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.max','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.min','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.name','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.orientation','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.placeholder','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.providesThumbs','false'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.readonly','false'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.requirable','false'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.size','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.step','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.tip','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.title','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.uid','\"ec0cbc02-7b53-4318-9214-fa84d1e25efb\"'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.userCondition','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.warning','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.elements.0.width','100'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.name','\"Content\"'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.uid','\"14bb8c37-3a51-48bc-a8e8-1512929ee687\"'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fieldLayouts.786f8719-4a80-4352-aa13-34232be85c35.tabs.0.userCondition','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.fs','\"uploads\"'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.handle','\"assets\"'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.name','\"Assets\"'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.sortOrder','2'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.subpath','\"\"'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.titleTranslationKeyFormat','null'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.titleTranslationMethod','\"site\"'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.transformFs','\"\"'),('volumes.71aefd52-fe8e-4c03-911c-8e5a2d7af4d5.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `relations` VALUES (3,2,11,NULL,10,1,'2024-11-25 00:02:33','2024-11-25 00:02:33','2efe19b0-bd1c-4a19-987a-e5c629d905c5'),(7,2,15,NULL,14,1,'2024-11-25 00:11:18','2024-11-25 00:11:18','2ad7a533-2f99-4ba2-8633-51d7a3a70543'),(12,2,19,NULL,18,1,'2024-11-25 00:31:23','2024-11-25 00:31:23','8d279708-5ad7-4166-be41-eb0b57468772'),(14,2,21,NULL,18,1,'2024-11-25 01:21:01','2024-11-25 01:21:01','dfc0a3b2-23b6-48b6-b4d8-cb630a5314d6'),(16,2,23,NULL,18,1,'2024-11-25 01:37:33','2024-11-25 01:37:33','c1f26c76-1e18-4e11-9e63-e7dff7309cb8'),(18,2,25,NULL,18,1,'2024-11-25 02:52:48','2024-11-25 02:52:48','e0f11f3d-a538-4aa7-843d-f2208de8bce9'),(20,2,27,NULL,18,1,'2024-11-25 02:53:10','2024-11-25 02:53:10','856d9fa9-910d-4263-a391-d444391cb5df'),(22,2,29,NULL,18,1,'2024-11-25 03:20:53','2024-11-25 03:20:53','4b49b99c-be42-42a1-b8c6-f1c9e196e474'),(23,2,30,NULL,18,1,'2024-11-25 03:20:59','2024-11-25 03:20:59','78e4e598-1e31-48fe-a205-97a5f2ac70c7'),(25,2,32,NULL,18,1,'2024-11-25 03:21:04','2024-11-25 03:21:04','ee9e6447-d10c-4d44-833d-5d336106f00e'),(27,2,34,NULL,18,1,'2024-11-25 03:44:52','2024-11-25 03:44:52','fa859eed-dfa3-4dd5-a162-c6e5cd9ae216'),(29,2,36,NULL,18,1,'2024-11-25 03:45:09','2024-11-25 03:45:09','2f7de124-c606-4c77-9853-4b00f7dfda3e'),(31,2,38,NULL,18,1,'2024-11-25 03:45:19','2024-11-25 03:45:19','16198517-6130-4a92-9a13-0bf01be37f92'),(32,2,39,NULL,18,1,'2024-11-25 03:45:21','2024-11-25 03:45:21','adf4ca9c-00dd-46b8-9530-b986bd0d7d27'),(34,2,41,NULL,18,1,'2024-11-25 03:45:34','2024-11-25 03:45:34','6c9501cf-786c-42a0-857b-3bb3b55a5b0c'),(36,2,43,NULL,18,1,'2024-11-25 04:21:34','2024-11-25 04:21:34','c68e9162-9492-41f6-b05a-4d9531d87561'),(38,2,45,NULL,18,1,'2024-11-25 04:25:27','2024-11-25 04:25:27','59c5bdee-a1aa-40f2-98e9-36657b3d6ece'),(40,2,47,NULL,18,1,'2024-11-25 04:46:02','2024-11-25 04:46:02','cd90436b-593b-4c14-a666-7643beb153b7'),(42,2,49,NULL,18,1,'2024-11-25 06:30:17','2024-11-25 06:30:17','61e9fc29-fbff-42e4-916c-01cb1f88ae51'),(43,2,50,NULL,18,1,'2024-11-25 06:35:03','2024-11-25 06:35:03','b0752007-53d2-4ce2-9842-1285b9eae735'),(45,2,52,NULL,18,1,'2024-11-25 06:44:01','2024-11-25 06:44:01','60a01583-ac3c-4010-aa93-f825411e0dd9'),(48,2,6,NULL,55,1,'2024-11-25 06:46:41','2024-11-25 06:46:41','be788aee-c331-45d3-baa6-436cea503c23'),(49,2,56,NULL,55,1,'2024-11-25 06:46:41','2024-11-25 06:46:41','2b151041-930f-4569-9341-672ef507b260'),(53,2,20,NULL,54,1,'2024-11-25 06:47:38','2024-11-25 06:47:38','da143e0d-62a8-4a90-82d4-dbd6194aa7e1'),(54,2,58,NULL,54,1,'2024-11-25 06:47:38','2024-11-25 06:47:38','e6eef217-021e-41e2-bd87-c394c4595fef'),(56,2,60,NULL,55,1,'2024-11-25 06:47:45','2024-11-25 06:47:45','f6acb098-92d1-4233-8655-11476a4de544'),(59,2,26,NULL,54,1,'2024-11-25 06:48:39','2024-11-25 06:48:39','367d81ce-36f5-4005-b30a-ae2b7e76f647'),(60,2,62,NULL,54,1,'2024-11-25 06:48:39','2024-11-25 06:48:39','96274ece-402c-406a-83dd-5922991b5d29'),(62,2,64,NULL,18,1,'2024-11-25 06:49:12','2024-11-25 06:49:12','bdfaae1e-d766-4468-b895-5eaa08a8aa0b'),(65,2,33,NULL,55,1,'2024-11-25 06:49:23','2024-11-25 06:49:23','88432b90-4139-445d-a06f-6b8484e62ed9'),(66,2,66,NULL,55,1,'2024-11-25 06:49:23','2024-11-25 06:49:23','f4b00c6f-b224-41ae-9ed2-2f88d896ce73'),(69,2,35,NULL,55,1,'2024-11-25 06:49:57','2024-11-25 06:49:57','dc61a204-aefe-4d09-bf6f-03aae5f8cc11'),(70,2,68,NULL,55,1,'2024-11-25 06:49:57','2024-11-25 06:49:57','713979bb-3c2b-4f03-963d-9d9ed19f1a29'),(72,2,70,NULL,18,1,'2024-11-25 06:50:34','2024-11-25 06:50:34','f15b0f4a-a04b-4661-b10a-11fd21f319ff'),(75,2,37,NULL,54,1,'2024-11-25 06:50:45','2024-11-25 06:50:45','e31491d3-202d-4c60-8d7b-608f0091b4f6'),(76,2,72,NULL,54,1,'2024-11-25 06:50:45','2024-11-25 06:50:45','809ad1d8-fc1e-48ce-bcaf-5f241d7d3313'),(78,2,74,NULL,55,1,'2024-11-25 06:55:56','2024-11-25 06:55:56','11eeb5b0-3072-4b22-a625-24c11999b6ea'),(80,2,76,NULL,54,1,'2024-11-25 06:56:01','2024-11-25 06:56:01','6ab430b2-fea0-41ec-a294-9a8262c8ec60'),(81,2,77,NULL,18,1,'2024-11-25 06:56:04','2024-11-25 06:56:04','0729baac-69dc-4d67-8ca1-23c96ade6745'),(83,2,79,NULL,55,1,'2024-11-25 06:56:27','2024-11-25 06:56:27','384c53df-35cc-4757-92ea-af7a1a1cfdb5'),(85,2,81,NULL,55,1,'2024-11-25 06:56:31','2024-11-25 06:56:31','2900b710-9e9f-40b1-9346-0c493de5dbd8'),(87,2,83,NULL,18,1,'2024-11-25 07:21:28','2024-11-25 07:21:28','b4a50dea-ebaa-4be1-85e3-93ca1f73e667'),(89,2,85,NULL,18,1,'2024-11-25 07:21:45','2024-11-25 07:21:45','8d88ac21-215e-4138-87fd-747a40586f0c'),(91,2,91,NULL,18,1,'2024-11-25 08:07:01','2024-11-25 08:07:01','04a8cdc1-4bb8-47b6-b5e8-e2e6410a3535'),(93,2,95,NULL,18,1,'2024-11-25 08:16:04','2024-11-25 08:16:04','056b52d4-27b3-43e7-9089-e4239a4f9c43'),(94,2,97,NULL,18,1,'2024-11-25 08:18:19','2024-11-25 08:18:19','d4dd5772-1700-48c1-b8c7-c71a3e824898'),(97,7,101,NULL,54,1,'2024-11-25 08:28:17','2024-11-25 08:28:17','e45a8eeb-2f84-4eb4-b560-ce03f1c4e4a6'),(98,2,102,NULL,18,1,'2024-11-25 08:28:17','2024-11-25 08:28:17','eb6e5d7e-da98-49af-8ff7-903c2683b746'),(99,7,103,NULL,54,1,'2024-11-25 08:28:17','2024-11-25 08:28:17','49cefdab-538d-49e1-a65f-ee1610b866fd'),(101,2,105,NULL,18,1,'2024-11-25 08:29:03','2024-11-25 08:29:03','607e7e31-cf0f-40d7-a859-d545b88ebb54'),(102,7,106,NULL,54,1,'2024-11-25 08:29:03','2024-11-25 08:29:03','8d8a03bb-9664-4ce0-9e65-b0dc7c58a765'),(105,2,40,NULL,55,1,'2024-11-25 09:30:08','2024-11-25 09:30:08','070e731b-5804-4356-841b-49a4274e7d7e'),(106,2,108,NULL,55,1,'2024-11-25 09:30:08','2024-11-25 09:30:08','f9daa3f7-3173-4f3e-a232-248369b2699b'),(107,7,109,NULL,54,1,'2024-11-25 09:30:08','2024-11-25 09:30:08','1069d692-e848-4541-920b-784f2040e86b'),(108,2,111,NULL,55,1,'2024-11-25 09:41:36','2024-11-25 09:41:36','6d68c2e8-de86-4577-9c31-9d573a21cd96'),(110,2,114,NULL,55,1,'2024-11-25 09:47:28','2024-11-25 09:47:28','350715b2-52b6-4581-bc5b-14a47abaa059'),(111,7,116,NULL,54,1,'2024-11-25 09:47:28','2024-11-25 09:47:28','31d1be57-59a9-47b2-9920-22685608bfe1'),(112,2,118,NULL,55,1,'2024-11-25 09:47:54','2024-11-25 09:47:54','87e9aee0-0296-428a-84dd-9f1479cfa924'),(113,2,120,NULL,55,1,'2024-11-25 09:48:35','2024-11-25 09:48:35','259bbeed-50a8-409f-b606-3bb08d66bfa9'),(116,2,123,NULL,55,1,'2024-11-25 10:10:34','2024-11-25 10:10:34','0354b358-bacb-45c1-b88a-0d2e4a5d61d8'),(117,7,124,NULL,54,1,'2024-11-25 10:10:34','2024-11-25 10:10:34','e1f1e84f-4cd0-4952-97be-5c3e4ec1c2ab'),(118,2,126,NULL,55,1,'2024-11-25 10:11:12','2024-11-25 10:11:12','1c9ebf4f-99da-4be4-b7bf-61ea0e71c094'),(120,2,129,NULL,55,1,'2024-11-25 10:11:29','2024-11-25 10:11:29','a556daba-e6a6-4d82-aad2-ffc844eb498e'),(123,2,133,NULL,54,1,'2024-11-25 11:10:33','2024-11-25 11:10:33','2006eea4-aded-4824-a012-2430282636c2'),(124,2,134,NULL,54,1,'2024-11-25 11:11:02','2024-11-25 11:11:02','7d634697-2b25-4975-96e9-26f63ed359ed'),(126,2,138,NULL,54,1,'2024-11-25 11:13:07','2024-11-25 11:13:07','40316d3f-0129-4244-a159-30662753fbc1'),(127,2,141,NULL,54,1,'2024-11-25 13:07:49','2024-11-25 13:07:49','2ac754d5-3919-4105-98d3-7ebe1c962d70');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES (1,4,1,1,NULL),(2,6,1,1,''),(3,6,1,2,'Applied “Draft 1”'),(4,6,1,3,'Applied “Draft 1”'),(5,6,1,4,'Applied “Draft 1”'),(6,20,1,1,''),(7,6,1,5,'Applied “Draft 1”'),(8,6,1,6,'Applied “Draft 1”'),(9,26,1,1,''),(10,6,1,7,'Applied “Draft 1”'),(11,20,1,2,''),(12,26,1,2,'Applied “Draft 1”'),(13,33,1,1,''),(14,35,1,1,''),(15,37,1,1,''),(16,37,1,2,''),(17,40,1,1,''),(18,40,1,2,'Applied “Draft 1”'),(19,40,1,3,'Applied “Draft 1”'),(20,37,1,3,'Applied “Draft 1”'),(21,40,1,4,'Applied “Draft 1”'),(22,6,1,8,''),(23,37,1,4,'Applied “Draft 1”'),(24,6,1,9,'Applied “Draft 1”'),(25,20,1,3,'Applied “Draft 1”'),(26,6,1,10,'Applied “Draft 1”'),(27,26,1,3,'Applied “Draft 1”'),(28,33,1,2,'Applied “Draft 1”'),(29,33,1,3,'Applied “Draft 1”'),(30,35,1,2,'Applied “Draft 1”'),(31,37,1,5,'Applied “Draft 1”'),(32,37,1,6,'Applied “Draft 1”'),(33,6,1,11,'Applied “Draft 1”'),(34,26,1,4,'Applied “Draft 1”'),(35,40,1,5,''),(36,35,1,3,'Applied “Draft 1”'),(37,33,1,4,'Applied “Draft 1”'),(38,40,1,6,'Applied “Draft 1”'),(39,40,1,7,'Applied “Draft 1”'),(40,40,1,8,'Applied “Draft 1”'),(41,90,1,1,NULL),(42,40,1,9,'Applied “Draft 1”'),(43,90,1,2,NULL),(44,40,1,10,''),(45,90,1,3,NULL),(46,40,1,11,'Applied “Draft 1”'),(47,101,1,1,NULL),(48,40,1,12,''),(49,101,1,2,NULL),(50,40,1,13,'Applied “Draft 1”'),(51,101,1,3,NULL),(52,40,1,14,''),(53,90,1,4,NULL),(54,40,1,15,''),(55,90,1,5,NULL),(56,101,1,4,NULL),(57,40,1,16,''),(58,90,1,6,NULL),(59,40,1,17,''),(60,40,1,18,''),(61,101,1,5,NULL),(62,40,1,19,''),(63,90,1,7,NULL),(64,40,1,20,'Applied “Draft 1”'),(65,4,1,2,NULL),(66,133,1,1,''),(67,133,1,2,'Applied “Draft 1”'),(68,137,1,1,NULL),(69,133,1,3,''),(70,137,1,2,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' abishekms7 gmail com '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' admin '),(2,'slug',0,1,' temp dmxflwzobuejpsfewxzkdbsbjicilehwuijm '),(2,'title',0,1,''),(3,'slug',0,1,' temp hwjjeudtemnlcfpjmjlbtivxusbedccnyvls '),(3,'title',0,1,''),(4,'slug',0,1,' homepage '),(4,'title',0,1,' homepage '),(6,'slug',0,1,' in egestas mauris non nunc volutpat efficitin ante finibus '),(6,'title',0,1,' in egestas mauris non nunc volutpat efficitin ante finibus '),(9,'alt',0,1,''),(9,'extension',0,1,' png '),(9,'filename',0,1,' frame 1 1 png '),(9,'kind',0,1,' image '),(9,'slug',0,1,''),(9,'title',0,1,' frame 1 1 '),(10,'alt',0,1,''),(10,'extension',0,1,' png '),(10,'filename',0,1,' frame 1 png '),(10,'kind',0,1,' image '),(10,'slug',0,1,''),(10,'title',0,1,' frame 1 '),(13,'alt',0,1,''),(13,'extension',0,1,' png '),(13,'filename',0,1,' frame 1 2024 11 25 001022 gatu png '),(13,'kind',0,1,' image '),(13,'slug',0,1,''),(13,'title',0,1,' frame 1 '),(14,'alt',0,1,''),(14,'extension',0,1,' jpg '),(14,'filename',0,1,' tree 736885 1280 jpg '),(14,'kind',0,1,' image '),(14,'slug',0,1,''),(14,'title',0,1,' tree 736885 1280 '),(17,'alt',0,1,''),(17,'extension',0,1,' jpg '),(17,'filename',0,1,' tree 736885 1280 2024 11 25 002238 qzuv jpg '),(17,'kind',0,1,' image '),(17,'slug',0,1,''),(17,'title',0,1,' tree 736885 1280 '),(18,'alt',0,1,''),(18,'extension',0,1,' jpg '),(18,'filename',0,1,' tree 736885 1280 jpg '),(18,'kind',0,1,' image '),(18,'slug',0,1,''),(18,'title',0,1,' tree 736885 1280 '),(20,'slug',0,1,' in egestas mauris non nunc volutpat efficitin ante finibus 2 '),(20,'title',0,1,' in egestas mauris non nunc volutpat efficitin ante finibus '),(26,'slug',0,1,' in egestas mauris non nunc volutpat efficitin ante finibus 3 '),(26,'title',0,1,' in egestas mauris non nunc volutpat efficitin ante finibus '),(33,'slug',0,1,' in egestas mauris non nunc volutpat efficitin ante finibus 4 '),(33,'title',0,1,' in egestas mauris non nunc volutpat efficitin ante finibus '),(35,'slug',0,1,' in egestas mauris non nunc volutpat efficitin ante finibus 5 '),(35,'title',0,1,' in egestas mauris non nunc volutpat efficitin ante finibus '),(37,'slug',0,1,' in egestas mauris non nunc volutpat efficitin ante finibus 6 '),(37,'title',0,1,' in egestas mauris non nunc volutpat efficitin ante finibus '),(40,'slug',0,1,' sed commodo mi nunc a auctor augue fringilla at '),(40,'title',0,1,' sed commodo mi nunc a auctor augue fringilla at '),(54,'alt',0,1,''),(54,'extension',0,1,' png '),(54,'filename',0,1,' frame 1 1 png '),(54,'kind',0,1,' image '),(54,'slug',0,1,''),(54,'title',0,1,' frame 1 1 '),(55,'alt',0,1,''),(55,'extension',0,1,' png '),(55,'filename',0,1,' frame 1 png '),(55,'kind',0,1,' image '),(55,'slug',0,1,''),(55,'title',0,1,' frame 1 '),(87,'slug',0,1,' temp vksgxzgudztedibtnezwtzqnzwcbiycsjpdt '),(87,'title',0,1,''),(88,'slug',0,1,' temp frtpaocdkilykvjqcstjzkyucpqenkurxygm '),(88,'title',0,1,''),(90,'slug',0,1,' content '),(90,'title',0,1,' content '),(101,'slug',0,1,' image and text '),(101,'title',0,1,' image and text '),(133,'slug',0,1,' sed commodo mi nunc a auctor augue fringilla at 2 '),(133,'title',0,1,' sed commodo mi nunc a auctor augue fringilla at '),(137,'slug',0,1,' text '),(137,'title',0,1,' text ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,NULL,'News','news','channel',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-11-24 20:08:09','2024-11-25 06:32:02',NULL,'98b466bb-97e7-448e-84a2-84a802931afd'),(2,NULL,'Homepage','homepage','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-11-24 21:00:08','2024-11-24 21:00:08',NULL,'fe86b1d3-9192-4dcd-ae58-c17f6b392a74');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_entrytypes` VALUES (1,1,1),(2,2,1);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'news/{slug}','news/_entry.twig',1,'2024-11-24 20:08:09','2024-11-25 06:32:02','200f9a89-7476-4267-b9d0-f2146af62f2e'),(2,2,1,1,'homepage','homepage/_entry.twig',1,'2024-11-24 21:00:08','2024-11-24 21:00:08','81dceef9-16f6-42e6-a9fe-ebc677567920');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'Craft Site','2024-11-24 20:04:52','2024-11-24 20:04:52',NULL,'721c4a33-2c28-47e7-b769-8356d8257154');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,'true','Craft Site','default','en-US',1,'$PRIMARY_SITE_URL',1,'2024-11-24 20:04:52','2024-11-24 20:04:52',NULL,'1b2cf952-a9ed-486a-8dd8-be74115414cf');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sso_identities`
--

LOCK TABLES `sso_identities` WRITE;
/*!40000 ALTER TABLE `sso_identities` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sso_identities` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structures` VALUES (1,NULL,'2024-11-25 06:06:12','2024-11-25 06:06:12',NULL,'278bf2a3-008a-417a-a521-3c0a76c7cf6a');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (1,'{\"language\": \"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'abishekms7@gmail.com','$2y$13$dgArs9mP7qLuViDNOu4vNunuR38lzzUHb3g3GLrye1zIsOeGFH/tW','2024-11-25 06:01:03',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-11-24 20:04:53','2024-11-24 20:04:53','2024-11-25 06:01:03');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Assets',NULL,'2024-11-24 23:57:38','2024-11-25 00:22:18','ba892c7e-321d-4fd9-920c-d979cec570ca'),(2,NULL,NULL,'Temporary Uploads',NULL,'2024-11-24 23:59:06','2024-11-24 23:59:06','9ab5f6aa-0df5-449b-8971-78ca8153149c'),(3,2,NULL,'user_1','user_1/','2024-11-24 23:59:06','2024-11-24 23:59:06','632d56cd-4a05-4b2d-b50f-d8d9fc70d4e2'),(4,NULL,2,'Assets','','2024-11-25 00:30:36','2024-11-25 00:30:36','55cb831a-8e84-4bce-8386-e444b83f9e54');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumes` VALUES (1,3,'Assets','assets','assets','','$PRIMARY_ASSETS_PATH','','site',NULL,'none',NULL,1,'2024-11-24 23:57:38','2024-11-25 00:22:18','2024-11-25 00:22:55','b43b117d-f248-40dd-9369-c4c50bb100f2'),(2,4,'Assets','assets','uploads','','','','site',NULL,'none',NULL,2,'2024-11-25 00:30:36','2024-11-25 00:30:36',NULL,'71aefd52-fe8e-4c03-911c-8e5a2d7af4d5');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2024-11-24 20:06:22','2024-11-24 20:06:22','45152299-ef9d-4584-9693-ff2f098f88fb'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-11-24 20:06:22','2024-11-24 20:06:22','d86a339e-111a-4a07-97b4-33885aa22feb'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-11-24 20:06:22','2024-11-24 20:06:22','db9443f4-d7d4-4073-9ce8-07035d6678a5'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}',1,'2024-11-24 20:06:22','2024-11-24 20:06:22','4f940d8c-5903-4673-9e44-5c4f8d9d3504');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-25 13:31:33
